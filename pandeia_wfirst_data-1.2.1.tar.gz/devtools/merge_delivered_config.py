#!/usr/bin/env python

# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
merge_delivered_config.py - simple script to take JSON configuration files as delivered from the JWST instrument teams
and merge any changed data into the pandeia configuration files.

this script takes two or three arguments.  for nircam, niriss, and miri, the two arguments are:
    <inst> - instrument name (nircam, niriss, miri, or nirspec)
    <delivered config> - JSON file containing data for updating instrument's config.json

for nirspec, an additional argument is required:
    <delivered shutter config> - JSON file containing data for updating nirspec's MSA shutter configuration file.
"""

import os
import sys
from copy import deepcopy
import numpy as np

from pandeia.engine.io_utils import read_json, write_json
from pandeia.engine.utils import get_key_list, set_dict_from_keys, get_dict_from_keys

SEP = '.'

def flatten(input, parent_key=None):
    outdict = {}
    if isinstance(input, dict):
        for k, v in input.items():
            if parent_key is not None:
                k = SEP.join((parent_key, k))
            outdict.update(flatten(v, parent_key=k))
    else:
        outdict[parent_key] = input
    return outdict

if len(sys.argv) < 3:
    print("Usage: merge_delivered_config.py <inst> <delivered config>")
    exit()

inst = sys.argv[1]
delivered = sys.argv[2]

if inst == 'nirspec':
    if len(sys.argv) != 4:
        print("Usage: merge_delivered_config.py nirspec <delivered config> <delivered shutter config>")
        exit()

config_file = os.path.join(os.environ['pandeia_refdata'], 'jwst', inst, 'config.json')
config = read_json(config_file)
output = deepcopy(config)
flat_config = flatten(config)

delivered_config = flatten(read_json(delivered))

for k in flat_config:
    keys = [k, SEP.join((k, "data"))]
    for key in keys:
        if key in delivered_config:
            if flat_config[k] != delivered_config[key]:
                print(k + ":", flat_config[k], "->", delivered_config[key])
                keylist = get_key_list(k, separator=SEP)
                set_dict_from_keys(output, keylist, delivered_config[key])

write_json(output, config_file, sort_keys=True)

if inst == 'nirspec':
    delivered_shutters = sys.argv[3]
    shutters_file = os.path.join(os.environ['pandeia_refdata'], 'jwst', inst, 'shutter_config.json')
    shutter_config = read_json(shutters_file)
    shutter_out = deepcopy(shutter_config)
    flat_shutter = flatten(shutter_config)
    delivered_shutter_config = flatten(read_json(delivered_shutters))
    for k in flat_shutter:
        keys = [k, SEP.join((k, "data"))]
        for key in keys:
            if key in delivered_shutter_config:
                if flat_shutter[k] != delivered_shutter_config[key]:
                    print(k + ":", flat_shutter[k], "->", delivered_shutter_config[key])
                    keylist = get_key_list(k, separator=SEP)
                    set_dict_from_keys(shutter_out, keylist, delivered_shutter_config[key])
    write_json(shutter_out, shutters_file, sort_keys=True)
