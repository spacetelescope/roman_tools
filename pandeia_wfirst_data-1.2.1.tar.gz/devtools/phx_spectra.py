#!/usr/bin/env python

from pandeia.engine.io_utils import write_json

"""
This script was used to parse the Phoenix model menu entries from the prototype ETC
and build a JSON config file out of the data.
"""

f = open("phx_spectra.txt")
lines = f.readlines()
f.close()

spectra = {}

for l in lines:
    sptyp, teff, logg = l.split()
    key = sptyp.lower()
    spectra[key] = {}
    spectra[key]['display_string'] = sptyp + " " + teff + " " + logg
    spectra[key]['teff'] = float(teff)
    spectra[key]['log_g'] = float(logg)
    spectra[key]['metallicity'] = 0.0

write_json(spectra, "spectra.json")
