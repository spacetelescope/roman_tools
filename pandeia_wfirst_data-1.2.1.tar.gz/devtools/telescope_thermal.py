#Hardcoded values from the MIRI ETC originally written by C. Chen. 

import numpy as np
from scipy.interpolate import interp1d
from astropy.analytic_functions import blackbody_nu
from astropy import units as u

def telescope_thermal(A_telescope=2.5e5,eta_telescope=0.88,temp_telescope=49.,eps_shade=2e-5,eta_shade=0.051):

    wavelengths = np.linspace(0.5,30,100)

    #calculate telescope thermal background
    eps_telescope = interp1d([0.5,11.3,30],[0.03,0.045,0.045]) #Assumed telescope emissivity
    I_telescope = blackbody_nu(wavelengths*u.micron,temp_telescope) * eps_telescope(wavelengths)/eta_telescope
    I_telescope = I_telescope.to(u.MJy/u.sr)

    #calculate sunshade thermal background
    #temp_shade = interp1d([0.5,5.6,7.7,10.0,11.3,12.8,15.,30.],[169.5,169.5,153.7,154.9,153.7,151.4,155.1,155.0])
    temp_shade = interp1d([0.5,30.],[95.0,95.0])
    
    I_shade = []
    for wave in wavelengths:
        I = blackbody_nu(wave*u.micron,temp_shade(wave)) * eps_shade * eta_shade
        I = I.to(u.MJy/u.sr)
        I_shade.append(I.value)

    I_shade = I_shade * u.MJy/u.sr
    I_tot = I_telescope + I_shade


    return wave, I_tot


