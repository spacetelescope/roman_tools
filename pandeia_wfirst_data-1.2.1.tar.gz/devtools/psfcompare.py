import numpy as np
import glob
from matplotlib import pyplot as plt
from matplotlib import gridspec
import sys
import os
import time
from astropy.io import fits

item1 = sys.argv[1]
item2 = sys.argv[2]


if os.path.isfile(item1):
    filename1 = [item1]
    filename2 = [item2]
elif os.path.isdir(item1):
    filename1 = glob.glob('{0:}/*.fits'.format(item1))
    filename2 = []
    for f in filename1:
        filename2.append('{0:}/{1:}'.format(item2,os.path.split(f)[1]))

oldcolor = (1,0,0)
newcolor = (0,1,0)

outfile = open('{0:}/psfcompare_{1:}.csv'.format(os.path.split(filename1[0])[0],time.strftime('%Y%m%dT%H%M%S')),'w')
outfile.write('name,max_new,max_old,sum_new,sum_old,upperthird_new,upperthird_old,centerthird_new,centerthird_old,maxdisc_vert,maxdisc_horz,median,stddev\n')

for i in range(len(filename1)):
    print filename1[i]
    try:
        file1 = fits.open(filename1[i])
        file2 = fits.open(filename2[i])
        
        data1 = file1[0].data
        data2 = file2[0].data
        size2 = np.int(np.round(len(data1)/2.0))
        size3 = np.int(np.floor(len(data1)/3.0))

        image = (data1-data2)/data2

        print np.min(data1),np.max(data1),np.min(data2),np.max(data2), np.min(image), np.max(image)
        
        fig = plt.figure(figsize=(10,10))
        ax1 = plt.subplot2grid((3,3),(0,0),colspan=2,rowspan=2)
        ax2 = plt.subplot2grid((3,3),(2,0),colspan=2)
        ax3 = plt.subplot2grid((3,3),(0,2),rowspan=2)
        ax4 = plt.subplot2grid((3,3),(2,2))
        fig.suptitle(os.path.split(filename1[i])[1])
        ax2.set_title('Horizontal 3-pixel Center Cut Sum')
        ax3.set_title('Vertical 3-px Cut Sum')
        ax4.set_title('New PSF (log)')
        ax1.set_ylabel('(New-Old)/Old')
        ax2.set_ylabel('Intensity')
        ax3.set_xlabel('Intensity')
        ax3.locator_params(axis='x',nticks=3)

        image = ax1.imshow((data1-data2)/data2)

        ax1.text(0.25,0.55,'Max:',horizontalalignment='center',transform=ax1.transAxes,color=(1,1,1))
        ax1.text(0.25,0.5,'{0:6.5f}'.format(np.max(data1)),horizontalalignment='center',transform=ax1.transAxes,color=newcolor)
        ax1.text(0.25,0.45,'{0:6.5f}'.format(np.max(data2)),horizontalalignment='center',transform=ax1.transAxes,color=oldcolor)

        ax1.text(0.25,0.85,'Upper Third:',horizontalalignment='center',transform=ax1.transAxes,color=(1,1,1))
        ax1.text(0.25,0.80,'{0:6.5f}'.format(np.sum(data1[0:size3,0:size3])),horizontalalignment='center',transform=ax1.transAxes,color=newcolor)
        ax1.text(0.25,0.75,'{0:6.5f}'.format(np.sum(data2[0:size3,0:size3])),horizontalalignment='center',transform=ax1.transAxes,color=oldcolor)

        ax1.text(0.5,0.55,'Center Third:',horizontalalignment='center',transform=ax1.transAxes,color=(1,1,1))
        ax1.text(0.5,0.5,'{0:6.5f}'.format(np.sum(data1[size3:size3*2,size3:size3*2])),horizontalalignment='center',transform=ax1.transAxes,color=newcolor)
        ax1.text(0.5,0.45,'{0:6.5f}'.format(np.sum(data2[size3:size3*2,size3:size3*2])),horizontalalignment='center',transform=ax1.transAxes,color=oldcolor)

        ax1.text(0.5,0.25,'Median: {0:6.5f}'.format(np.median((data1-data2)/data1)),horizontalalignment='center',transform=ax1.transAxes,color=(1,1,1))
        ax1.text(0.5,0.20,'StdDev: {0:8.7f}'.format(np.std((data1-data2)/data1)),horizontalalignment='center',transform=ax1.transAxes,color=(1,1,1))
        
        ax1.text(0.75,0.55,'Total Sum:',horizontalalignment='center',transform=ax1.transAxes,color=(1,1,1))
        ax1.text(0.75,0.5,'{0:6.5f}'.format(np.sum(data1)),horizontalalignment='center',transform=ax1.transAxes,color=newcolor)
        ax1.text(0.75,0.45,'{0:6.5f}'.format(np.sum(data2)),horizontalalignment='center',transform=ax1.transAxes,color=oldcolor)
        fig.colorbar(image, ax=ax1)

        horizontal1 = np.sum(data1[size2-1:size2+2],axis=0)
        horizontal2 = np.sum(data2[size2-1:size2+2],axis=0)
        vertical1 = np.sum(data1[:,size2-1:size2+2],axis=1)
        vertical2 = np.sum(data2[:,size2-1:size2+2],axis=1)
        ax2.plot(range(len(data1)),horizontal1,color=newcolor)
        ax2.plot(range(len(data2)),horizontal2,color=oldcolor)

        ax3.plot(vertical1,range(len(data1)),color=newcolor)
        ax3.plot(vertical2,range(len(data2)),color=oldcolor)
        ax3.text(0.25,0.85,'New',horizontalalignment='center',transform=ax3.transAxes,color=newcolor)
        ax3.text(0.25,0.8,'Old',horizontalalignment='center',transform=ax3.transAxes,color=oldcolor)

        ax4.imshow(np.log(data1),cmap='gray')

        outfile.write('{0:40},{1: 6.5f},{2: 6.5f},{3: 6.5f},{4: 6.5f},'.format(os.path.split(filename2[i])[1],np.max(data1),np.max(data2),np.sum(data1),np.sum(data2)))
        outfile.write('{0: 6.5f},{1: 6.5f},{2: 6.5f},{3: 6.5f},'.format(np.sum(data1[0:size3,0:size3]),np.sum(data2[0:size3,0:size3]),np.sum(data1[size3:size3*2,size3:size3*2]),np.sum(data2[size3:size3*2,size3:size3*2])))
        outfile.write('{0: 6.5f},{1: 6.5f},{2: 6.5f},{3: 6.5f}\n'.format(np.max((horizontal1-horizontal2)/horizontal1),np.max((vertical1-vertical2)/vertical1),np.median((data1-data2)/data1),np.std((data1-data2)/data1)))
        plt.tight_layout()

        # both names are in the split filename1[i]
        plt.savefig('{0:}/{1:}_comparison.png'.format(os.path.split(filename1[i])[0],os.path.split(filename1[i])[1]))
        plt.close()
        plt.clf()
    except IOError:
        pass
    
outfile.close()
