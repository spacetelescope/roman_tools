import pysynphot as s
import numpy as np
import glob
from matplotlib.mlab import find
from astropy.io import fits
import os
import itertools

from pysynphot import observation
from pysynphot import spectrum
 
# http://www.astrobetter.com/blog/2013/08/12/python-tip-re-sampling-spectra-with-pysynphot/
def rebin_spec(wave, specin, wavnew):
    spec = spectrum.ArraySourceSpectrum(wave=wave, flux=specin)
    f = np.ones(len(wave))
    filt = spectrum.ArraySpectralElement(wave, f, waveunits='angstrom')
    obs = observation.Observation(spec, filt, binset=wavnew, force='taper')
    return obs.binflux

rpower = 6000.
wmin = 0.55
wmax = 30.
dlmin = wmin/rpower

# Going to have an initial spacing of 0.007 per Klaus, but put into angstroms
wave = wmin
new_wave = []
while wave<wmax:
    new_wave.append(wave)
    wave += dlmin*wave/wmin
new_wave = np.array(new_wave) * 1e4

# Read in the data
files = [x for x in glob.glob('files2downsample/*.fits') if not 'trimmed' in x]

for filename in files:

    # Grab the original data
    hst_spectrum = s.FileSpectrum(filename)

    # Now rebin to the new wavelength array
    new_flux = rebin_spec(hst_spectrum.wave, hst_spectrum.flux, new_wave)

    # Now save the data
    tt = s.ArraySpectrum(new_wave, new_flux, fluxunits='flam')
    tt.writefits(filename.replace('.fits', '')+'_trimmed_logdownsampled.fits')

    print('Original file {} had {} points, rebinned to {}.'.format(filename, len(hst_spectrum.wave), len(new_wave)))
