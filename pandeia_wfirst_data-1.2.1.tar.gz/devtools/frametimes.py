import json
import sys
import os
import numpy as np
from astropy.io import fits

def calc_frametime(nx,ny,namp,colpad,rowpad,pixpad):
    return ((float(nx)/float(namp) + colpad) * (ny + rowpad) + pixpad) * 1e-5

telescope = 'jwst'

filedata = open(sys.argv[1])

config = json.load(filedata)


subarrays = config['subarrays']

print('Subarray\tCurrent\tStrip\tWindow')
for subarray in subarrays:
    nx = config['subarray_config']['default'][subarray]['nx']
    ny = config['subarray_config']['default'][subarray]['ny']

    print('{0:}:\t{1:}\t{2:}\t{3:}'.format(subarray,config['subarray_config']['default'][subarray]['tframe'],calc_frametime(nx,ny,4,12,1,1),calc_frametime(nx,ny,1,12,2,0)))

