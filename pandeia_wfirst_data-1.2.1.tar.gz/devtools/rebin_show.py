import pysynphot as s
import numpy as np
from matplotlib.mlab import find
from astropy.io import fits
import os
import itertools

from pysynphot import observation
from pysynphot import spectrum

#filename = 'files2downsample/g191b2b_mod_009.fits'
filename = 'files2downsample/p330e_stisnic_004.fits'
filename_rebin = filename.replace('.fits', '_jwst_trimmed_downsampled.fits')

hst_spectrum = s.FileSpectrum(filename)
hst_spectrum_rebin = s.FileSpectrum(filename_rebin)

figure(1)
clf()
plot(hst_spectrum.wave, hst_spectrum.flux, 'b:')
plot(hst_spectrum_rebin.wave, hst_spectrum_rebin.flux, 'r--')
gca().set_xscale('log') 
gca().set_yscale('log') 
gca().set_xlim((0.5*1e4,31*1e4))
xlabel('Wavelength (angstroms)', fontsize=14)
ylabel('Flux', fontsize=14)
legend([
    'Original [{} points]'.format(len(hst_spectrum.wave)), 
    'Rebinned [{} points]'.format(len(hst_spectrum_rebin.wave))
]) 
title(filename)
grid('on')
