import pysynphot as s
import numpy as np
from matplotlib.mlab import find
from astropy.io import fits
import os
import itertools

from pysynphot import observation
from pysynphot import spectrum

# The problem is that some calculations were running very slowly due to large HST spectral files. The rebin.py
# file will rebin the data and save with a new extension. The algorithm is a multi-step method that calculates
# an intermediate curve, determines where the flux deviates and then includes those regions and does a final rebinning.
# Issue: STScI-SSB/pandeia#2452

# http://www.astrobetter.com/blog/2013/08/12/python-tip-re-sampling-spectra-with-pysynphot/
def rebin_spec(wave, specin, wavnew):
    spec = spectrum.ArraySourceSpectrum(wave=wave, flux=specin)
    f = np.ones(len(wave))
    filt = spectrum.ArraySpectralElement(wave, f, waveunits='angstrom')
    obs = observation.Observation(spec, filt, binset=wavnew, force='taper')
    return obs.binflux

# Read in the data
files = [x for x in glob.glob('files2downsample/*.fits') if not 'trimmed' in x]

for filename in files:

    # Grab the original data
    hst_spectrum = s.FileSpectrum(filename)
    wave = hst_spectrum.wave
    flux = hst_spectrum.flux

    # Clip in microns
    inds = find( (wave/1e4 >= 0.5) & ( wave/1e4 <= 31))

    # Going to have an initial spacing of 0.007 per Klaus, but put into angstroms
    new_wave = linspace(0.5, 31, (31-0.5)/0.007)*1e4

    # Now rebin to the new wavelength array
    new_flux = rebin_spec(hst_spectrum.wave, flux, new_wave)

    # Re-bin back to the original wavelengths, so we can check and see 
    # how this matches up with the original data.
    rebinned_original_flux = rebin_spec(new_wave, new_flux, hst_spectrum.wave)

    # Find the places in the original data that just don't match
    # so we know where we have to add in more points.  Going to see
    # which ones are more than 0.5% different.
    inds = find( (abs(flux-rebinned_original_flux)/flux*100 > 0.5) & 
            (wave>=0.5*1e4) & (wave<=31*1e4) & 
            (flux>0))

    # Now add in wavelengths and re-bin to the new fluxes 
    add_in_wavelengths = wave[inds]
    new_wave_expanded = np.append( new_wave, add_in_wavelengths )
    new_wave_expanded.sort()
    new_wave_expanded = unique(new_wave_expanded)
    new_flux_expanded = rebin_spec(wave, flux, new_wave_expanded)

    # Now save the data
    tt = s.ArraySpectrum(new_wave_expanded, new_flux_expanded)
    tt.writefits(filename.replace('.fits', '')+'_jwst_trimmed_downsampled.fits')

    print('Original file {} had {} points, rebinned to {}.'.format(filename, len(wave), len(new_wave_expanded)))
