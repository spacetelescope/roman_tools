from csv2fits import csv2fits_thruput as csv2fits

infiles = ['../jwst/miri/blaze/p750l_blaze.csv']
outfiles = ['../jwst/miri/blaze/p750l_blaze.fits']

for infile, outfile in zip(infiles, outfiles):
    csv2fits(infile, outfile)
