#!/usr/bin/env python

import webbpsf as wp
import numpy as np
import os
import astropy.io.fits as pf
from pandeia.engine.io_utils import read_json
import pandeia.engine.config as cf

default_refdata_directory = cf.default_refdata_directory


def psf_suite(nw=30, wmin=0.5, wmax=6., instrument=None,
              outname='PSF', fov_arcsec=None, fov_pixels=None, oversample=3,
              aperture='any', rot90=False, source_offset_r=0., source_offset_theta=0.,
              optimal_offset_r=None, optimal_offset_theta=None, trim_fov_pixels=None,
              detector_scat=None):
    """
    Method to calculate a suite (range of wavelengths) of monochromatic PSFs
    with a format appropriate for use with Pandeia.

    Keywords
    --------
    nw: integer
        Number of wavelength planes
    wmin: float
        Minimum wavelength (in microns)
    wmax: float
        Maximum wavelength (in microns)
    instrument: WebbPSF instrument class
        The instrument/mode to use. Has to be instantiated prior to the call
        using WebbPSF
    outname: string
        Base name for the output PSF files
    fov_arcsec: float
        Size of the field of view in arcseconds. Cannot be specified at the
        same time as fov_pixels.
    fov_pixels: integer
        Size of the field of view in detector (not oversampled) pixels. Cannot
        be specified at the same time as fov_arcsec
    aperture: string
        name of the aperture relevant for the PSF. This name is used by
        Pandeia to match the PSFs in a library to a given instrument/mode.
    rot90: bool
        rotate the PSF by 90 degrees. The Pandeia convention is to disperse
        spectra in the horizontal (x) direction. This may not match the WebbPSF
        assumption. Eventually, this may be superseded by a more stringent
        treatment of detector/dispersion/sky axes.
    source_offset_r: float
        radial distance of source from optical axis
    source_offset_theta: float
        angular coordinate of source position measured in degrees CCW from +Y axis
    optimal_offset_r: float
        radial offset from optimal position along masklwb or maskswb
    optimal_offset_theta: float
        angular offset in degrees CCW from +Y centered at optimal position
    trim_fov_pixels: int (must be odd!)
        Trimmed size of the field of view in detector (not oversampled) pixels.
    detector_scat: function of wavelength, returns a float between 0 and 1
        The detector may scatter light to large distances, leading to an effective
        loss of throughput in sources (the background is not affected). This is
        an issue for MIRI, but not currently for the other instruments
        (see Glasse et al. 2015). This function will decrease the PSF throughput by
        a factor.
    """

    nw = float(nw)
    waves = (np.arange(nw) / (nw - 1)) ** 2. * (wmax - wmin) + wmin
    waves_m = waves * 1e-6

    # First calculate a PSF in the first wavelength bin for the maximal FOV to calculated the pupil loss.
    # Note that the pupil loss is constant as a function of wavelength, so we only need to do this once per
    # psf_suite
    
    # The maximum FOV size is 512 lambda/D (according to M. Perrin, priv. comm.)
    fov_arcsec = 512.0 * waves_m[0]/6.5 * 206265.0
    instrument.options['source_offset_r'] = source_offset_r
    instrument.options['source_offset_theta'] = source_offset_theta
    if optimal_offset_r is not None:
        instrument.options['bar_offset'] = 0.0
    instrument.include_si_wfe = True

    psf_full_fov = instrument.calcPSF(oversample=oversample, 
                                      fov_arcsec=fov_arcsec, 
                                      monochromatic=waves_m[0])
                                      
    pupil_throughput = np.sum(psf_full_fov[0].data)

    for wave in waves_m:
        if optimal_offset_r is not None:
            # Basename + aperture + wavelength + (if non-trivial) distance from optimal bar position and
            # angle from vertical as defined in WebbPSF
            longname = outname + '_' + aperture + '_{0:.4f}'.format(wave * 1e6) + \
                '_{0:.3f}'.format(optimal_offset_r) + '_{0:.0f}'.format(optimal_offset_theta) + '.fits'
        elif source_offset_r > 0.:
            # Basename + aperture + wavelength + (if non-trivial) distance from on-axis and
            # angle from vertical as defined in WebbPSF
            longname = outname + '_' + aperture + '_{0:.4f}'.format(wave * 1e6) + \
                '_{0:.3f}'.format(source_offset_r) + '_{0:.0f}'.format(source_offset_theta) + '.fits'
        else:
            longname = outname + '_' + aperture + '_{0:.4f}'.format(wave * 1e6) + '.fits'

        longname = longname.lower()
        if os.path.isfile(longname):
            print("%s already exists. skipping..." % longname)
            continue
        else:
            print("Creating %s..." % longname)

        instrument.options['output_mode'] = 'oversampled'
        instrument.options['parity'] = 'odd'

        """
        The oversample parameter default to 3. This is a decision based on
        three considerations 1) accuracy - many JWST modes are natively
        undersampled. Therefore, oversampling=1 is rarely sufficient. 2) The
        oversampling factor *must* currently be odd, otherwise the internal
        Pandeia PSF convolution will result in half-pixel spatial shifts. 3)
        Performance - the calculation time for a NxN image scales as
        O(N^2 log2 (N)), so oversampling factors larger than 3 rapidly lead
        to excessive calculation times.
        """

        # If off-axis, return center to origin
        if source_offset_r > 0:
            source_offset_theta_rad = np.radians(source_offset_theta)
            # Round to nearest integer subsampled pixel to avoid interpolations.
            # in webbpsf, when theta is 0, r is aligned with the +Y axis and theta increases CCW from there
            dx = source_offset_r * np.sin(source_offset_theta_rad)
            dy = source_offset_r * np.cos(source_offset_theta_rad)
            dx_pix = dx / instrument.pixelscale
            dy_pix = dy / instrument.pixelscale
            dx_pix_round = int(np.rint(dx_pix))
            dy_pix_round = int(np.rint(dy_pix))
            source_offset_r_pix = np.sqrt(dx_pix_round**2 + dy_pix_round**2)
            if dx_pix_round > 0 and np.abs(source_offset_theta) != 90.0:
                source_offset_theta = np.degrees(np.arctan(np.abs(dy_pix_round / dx_pix_round)))

            instrument.options['source_offset_r'] = source_offset_r_pix * instrument.pixelscale
            instrument.options['source_offset_theta'] = source_offset_theta
            # WebbPSF is able to set the bar offset itself, but we do it manually, so we must turn off this WebbPSF feature
            if optimal_offset_r is not None:
                instrument.options['bar_offset'] = 0.0

            dmax = np.max([np.abs(dx_pix_round), np.abs(dy_pix_round)])
            instrument.calcPSF(oversample=oversample, fov_pixels=fov_pixels + 2 * dmax, monochromatic=wave,
                               outfile=longname, overwrite='true')
            psf = pf.open(longname, mode='update')

            psf[0].data = np.roll(psf[0].data, dx_pix_round * oversample, axis=1)
            psf[0].data = np.roll(psf[0].data, -dy_pix_round * oversample, axis=0)
            psf[0].data = psf[0].data[dmax * oversample:(fov_pixels + dmax) * oversample,
                                      dmax * oversample:(fov_pixels + dmax) * oversample]
            if trim_fov_pixels is not None and fov_pixels is not None:
                trim_amount = int(oversample * (fov_pixels - trim_fov_pixels) / 2)
                psf[0].data = psf[0].data[trim_amount:-trim_amount, trim_amount:-trim_amount]
            psf.close()
        else:
            instrument.options['source_offset_r'] = 0.
            instrument.options['source_offset_theta'] = 0.            
            # WebbPSF is able to set the bar offset itself, but we do it manually, so we must turn off this WebbPSF feature
            if optimal_offset_r is not None:
                instrument.options['bar_offset'] = 0.0

            instrument.calcPSF(oversample=oversample, fov_pixels=fov_pixels, monochromatic=wave,
                               outfile=longname, overwrite='true')

        # Add mode keyword to header
        hdulist = pf.open(longname)
        prihdr = hdulist[0].header
        prihdr['MAKE_PSF'] = (MAKE_PSF_VERSION, 'Version of make_psf used to generate these files')
        prihdr['PUP_THRU'] = (pupil_throughput, 'The relative throughput of the pupil')
        prihdr['APERTURE'] = (aperture, 'The observing aperture within the instrument FOV')
        prihdr['OFFSET_R'] = (source_offset_r, 'The radial distance in arcsec to the axis')
        prihdr['OFFSET_T'] = (source_offset_theta, 'The source angle in degrees')
        if optimal_offset_r is not None and optimal_offset_theta is not None:
            prihdr['OPTOFF_R'] = (optimal_offset_r, 'radial distance to optimal FOV position')
            prihdr['OPTOFF_T'] = (optimal_offset_theta, 'source angle in degrees relative to optimal FOV position')

        if rot90:
            hdulist[0].data = np.rot90(hdulist[0].data)

        if detector_scat is not None:
            hdulist[0].data *= detector_scat(wave*1e6)

        hdulist.writeto(longname, overwrite=True)
        hdulist.close()


def MIRI_detector_scat(wave):
    '''
    The loss due to detector scattering in the
    MIRI imaging detector. See Glasse et al. 2015, PASP, 127, 686 for details.
    '''
    a_det = 0.32
    tau1 = 0.36
    tau2 = 0.85
    f_det = 1. - a_det * np.exp(-(tau1 + tau2) * (wave / 7.)**2.)
    return f_det

MAKE_PSF_VERSION = 1.1
doMIRI = True
doNIRSpec = True
doNIRCam = True
doNIRISS = True
doCORONAGRAPHY = True

if doMIRI:

    if doCORONAGRAPHY:
        coronagraph_source_offsets = [(0., 0.), (0.005, 45.), (0.5, 45.), (1.0, 45.), (2.0, 45.)]

        for offset in coronagraph_source_offsets:
            MIRI_FQPM = wp.MIRI()
            MIRI_FQPM.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
            MIRI_FQPM.pupil_mask = 'MASKFQPM'
            MIRI_FQPM.image_mask = 'FQPM1065'
            psf_suite(nw=90, wmin=4.7, wmax=22.0, instrument=MIRI_FQPM,
                      outname='miri', fov_pixels=81, aperture='fqpm1065',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

            MIRI_FQPM = wp.MIRI()
            MIRI_FQPM.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
            MIRI_FQPM.pupil_mask = 'MASKFQPM'
            MIRI_FQPM.image_mask = 'FQPM1140'
            psf_suite(nw=90, wmin=4.7, wmax=22.0, instrument=MIRI_FQPM,
                      outname='miri', fov_pixels=81, aperture='fqpm1140',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

            MIRI_FQPM = wp.MIRI()
            MIRI_FQPM.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
            MIRI_FQPM.pupil_mask = 'MASKFQPM'
            MIRI_FQPM.image_mask = 'FQPM1550'
            psf_suite(nw=90, wmin=4.7, wmax=22.0, instrument=MIRI_FQPM,
                      outname='miri', fov_pixels=81, aperture='fqpm1550',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

            MIRI_FQPM = wp.MIRI()
            MIRI_FQPM.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
            MIRI_FQPM.pupil_mask = 'MASKLYOT'
            MIRI_FQPM.image_mask = 'LYOT2300'
            psf_suite(nw=110, wmin=4.7, wmax=26.5, instrument=MIRI_FQPM,
                      outname='miri', fov_pixels=81, aperture='lyot2300',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

    MIRI = wp.MIRI()
    MIRI.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
    MIRI.pixelscale = 0.196
    psf_suite(nw=30, wmin=4., wmax=8., instrument=MIRI,
              outname='miri', fov_pixels=21, aperture='ch1', detector_scat=MIRI_detector_scat)
    MIRI = wp.MIRI()
    MIRI.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
    MIRI.pixelscale = 0.196
    psf_suite(nw=30, wmin=7., wmax=12., instrument=MIRI,
              outname='miri', fov_pixels=23, aperture='ch2', detector_scat=MIRI_detector_scat)
    MIRI = wp.MIRI()
    MIRI.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
    MIRI.pixelscale = 0.245
    psf_suite(nw=30, wmin=11., wmax=19., instrument=MIRI,
              outname='miri', fov_pixels=25, aperture='ch3', detector_scat=MIRI_detector_scat)
    MIRI = wp.MIRI()
    MIRI.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
    MIRI.pixelscale = 0.273
    psf_suite(nw=30, wmin=17., wmax=30., instrument=MIRI,
              outname='miri', fov_pixels=29, aperture='ch4', detector_scat=MIRI_detector_scat)
    MIRI = wp.MIRI()
    MIRI.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
    MIRI.pixelscale = 0.11
    psf_suite(nw=30, wmin=4., wmax=30., instrument=MIRI,
              outname='miri', fov_pixels=51, aperture='imager', detector_scat=MIRI_detector_scat)

    MIRI = wp.MIRI()
    MIRI.pupilopd = 'OPD_RevW_ote_for_MIRI_requirements.fits.gz'
    MIRI.pixelscale = 0.11
    MIRI.image_mask = "LRS slit"
    MIRI.pupil_mask = "P750L LRS grating"
    # The PSF creation for the MIRI LRS mode goes here. It is not functional yet, pending complete WebbPSF implementation.
    # MIRI.pupil_mask = 'P750L LRS grating'
    psf_suite(nw=30, wmin=4., wmax=15., instrument=MIRI,
              outname='miri', fov_pixels=55, aperture='lrsslit', detector_scat=MIRI_detector_scat)

if doNIRCam:
    # read the instrument configuration file which contains information needed to configure the PSFs for coronagraphy
    ref_dir = os.path.join(default_refdata_directory, "jwst", "nircam")
    config = read_json(os.path.join(ref_dir, "config.json"), raise_except=True)

    # Set these up to read in the current JWST.cfg to get the appropriate pixel sizes, rather than hard coding them.
    NIRCam = wp.NIRCam()
    NIRCam.include_si_wfe = True
    NIRCam.pixelscale = 0.0311
    NIRCam.detector = 'A1'  # A1-A4 are SW, A5 is LW
    NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
    psf_suite(nw=30, wmin=0.6, wmax=2.35, instrument=NIRCam,
              outname='nircam', fov_pixels=51, aperture='sw')

    NIRCam = wp.NIRCam()
    NIRCam.include_si_wfe = True
    NIRCam.pixelscale = 0.063
    NIRCam.detector = 'A5'  # A1-A4 are SW, A5 is LW
    NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
    psf_suite(nw=30, wmin=2.35, wmax=5.3, instrument=NIRCam,
              outname='nircam', fov_pixels=51, aperture='lw')

    if doCORONAGRAPHY:
        coronagraph_source_offsets = [(0., 0.), (0.007, 45.), (0.4, 45.), (0.8, 45.), (1.2, 45.)]
        for offset in coronagraph_source_offsets:
            NIRCam = wp.NIRCam()
            NIRCam.include_si_wfe = True
            NIRCam.pixelscale = 0.0311
            NIRCam.detector = 'A1'  # A1-A4 are SW, A5 is LW
            NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
            NIRCam.pupil_mask = 'CIRCLYOT'
            NIRCam.image_mask = 'MASK210R'

            psf_suite(nw=10, wmin=1.5, wmax=2.35, instrument=NIRCam,
                      outname='nircam', fov_pixels=101, aperture='mask210r',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

        coronagraph_source_offsets = [(0., 0.), (0.007, 45.), (0.64, 45.), (1.0, 45.), (1.5, 45.)]
        for offset in coronagraph_source_offsets:
            NIRCam = wp.NIRCam()
            NIRCam.include_si_wfe = True
            NIRCam.pixelscale = 0.063
            NIRCam.detector = 'A5'  # A1-A4 are SW, A5 is LW
            NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
            NIRCam.pupil_mask = 'CIRCLYOT'
            NIRCam.image_mask = 'MASK335R'

            psf_suite(nw=30, wmin=2.35, wmax=5.3, instrument=NIRCam,
                      outname='nircam', fov_pixels=101, aperture='mask335r',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

        coronagraph_source_offsets = [(0., 0.), (0.007, 45.), (0.82, 45.), (1.2, 45.), (1.6, 45.)]
        for offset in coronagraph_source_offsets:
            NIRCam = wp.NIRCam()
            NIRCam.include_si_wfe = True
            NIRCam.pixelscale = 0.063
            NIRCam.detector = 'A5'  # A1-A4 are SW, A5 is LW
            NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
            NIRCam.pupil_mask = 'CIRCLYOT'
            NIRCam.image_mask = 'MASK430R'

            psf_suite(nw=30, wmin=2.35, wmax=5.3, instrument=NIRCam,
                      outname='nircam', fov_pixels=101, aperture='mask430r',
                      source_offset_r=offset[0], source_offset_theta=offset[1])

        # for the occulting bars, we need to move the source along the bar as a function of wavelength to
        # optimize the performance of the occulter. get the optimal offset for each filter from the instrument config file.
        # the offsets are in arcseconds and increase with bar thickness (i.e. negative offsets are at the narrower
        # end; positive at wider end). also get which filters go with each bar from the config file.
        bar_offsets = config['bar_offsets']
        lwb_filters = config['config_constraints']['apertures']['masklwb']['filters']['default']
        swb_filters = config['config_constraints']['apertures']['maskswb']['filters']['default']

        # We don't need a separate PSF library for the neutral density spots. 
        lwb_filters = [filter for filter in lwb_filters if '_nd' not in filter]
        swb_filters = [filter for filter in swb_filters if '_nd' not in filter]

        # the bars are rotated -90 degrees w.r.t. the webbpsf coordinate system
        bar_angle = 90.0

        # these functions provide the bar width as a function of X (i.e. bar_offset in arcsec).
        # the source offsets will be in units of bar width for consistency.
        def swb_width(x):
            width = 0.2666 + 0.01777 * x
            return width

        def lwb_width(x):
            width = 0.5839 + 0.03893 * x
            return width

        # the bar isn't symmetric left to right so need +/-5 and +/-175.
        angles = [-5.0, 5.0, -90.0, 90.0, -175.0, 175.0]
        # these correspond to 0%, 50%, 75%, 90%, and 100% tramsmission
        src_offsets = [0.5, 0.61, 0.705, 2.5]

        NIRCam = wp.NIRCam()
        NIRCam.include_si_wfe = True
        NIRCam.pixelscale = 0.063
        NIRCam.detector = 'A5'  # A1-A4 are SW, A5 is LW
        NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
        NIRCam.pupil_mask = 'WEDGELYOT'
        NIRCam.image_mask = 'MASKLWB'

        # loop through the filters for MASKLWB and make a set of PSFs for each one centered at the optimal bar position
        for filt in lwb_filters:
            # get the optimal bar position for filt
            x = bar_offsets[filt]
            aperture_name = "masklwb%s" % filt
            wrange = config['range']['masklwb'][filt]
            wmin = wrange['wmin']
            wmax = wrange['wmax']
            nw = int(10.0 * (wmax - wmin))  # uniformly space PSFs by 0.1 um

            # set the initial coronagraph location at this optimal position. r is always
            # positive so pull sign out and apply it to the angle.
            r_img = np.abs(x)
            theta_img = np.sign(x) * bar_angle
            psf_suite(nw=nw, wmin=wmin, wmax=wmax, instrument=NIRCam,
                      outname='nircam', fov_pixels=351, aperture=aperture_name,
                      source_offset_r=r_img, source_offset_theta=theta_img,
                      optimal_offset_r=0.0, optimal_offset_theta=0.0, trim_fov_pixels=101)
            # now loop through the offsets and angles for positions around the optimal position
            for offset in src_offsets:
                for angle in angles:
                    width = lwb_width(x)
                    offset_arcsec = width * offset  # offsets in units of bar widths
                    rad = np.radians(angle)
                    # dx and dy are arcsec from the optical position for filt.
                    # in pandeia, 0 degrees is along +X axis rather than +Y like webbpsf.
                    # also X increases to right in pandeia, to left in webbpsf...
                    dx = offset_arcsec * np.cos(rad)
                    dy = offset_arcsec * np.sin(rad)
                    r = np.sqrt(dx**2 + dy**2)
                    # now use the bar_offset to get the r and theta values referenced to the bar center that
                    # we need to pass to webbpsf
                    x_img = x - dx  # this is because of webbpsf X flip...
                    r_img = np.sqrt(x_img**2 + dy**2)
                    theta_img = np.degrees(np.arctan2(dy, x_img)) - np.sign(x) * bar_angle
                    # the angle used in filenaming needs to be positive...
                    if angle < 0.0:
                        angle += 360.0

                    psf_suite(nw=nw, wmin=wmin, wmax=wmax, instrument=NIRCam,
                              outname='nircam', fov_pixels=351, aperture=aperture_name,
                              source_offset_r=r_img, source_offset_theta=theta_img,
                              optimal_offset_r=r, optimal_offset_theta=angle, trim_fov_pixels=101)

        NIRCam = wp.NIRCam()
        NIRCam.include_si_wfe = True
        NIRCam.pixelscale = 0.0311
        NIRCam.detector = 'A1'  # A1-A4 are SW, A5 is LW
        NIRCam.pupilopd = 'OPD_RevW_ote_for_NIRCam_requirements.fits.gz'
        NIRCam.pupil_mask = 'WEDGELYOT'
        NIRCam.image_mask = 'MASKSWB'

        # loop through the filters for MASKLWB and make a set of PSFs for each one centered at the optimal bar position
        for filt in swb_filters:
            # get the optimal bar position for filt
            x = bar_offsets[filt]
            aperture_name = "maskswb%s" % filt
            wrange = config['range']['maskswb'][filt]
            wmin = wrange['wmin']
            wmax = wrange['wmax']
            nw = int(10.0 * (wmax - wmin))  # uniformly space PSFs by 0.1 um

            # set the initial coronagraph location at this optimal position. r is always
            # positive so pull sign out and apply it to the angle.
            r_img = np.abs(x)
            theta_img = np.sign(x) * bar_angle
            psf_suite(nw=nw, wmin=wmin, wmax=wmax, instrument=NIRCam,
                      outname='nircam', fov_pixels=351, aperture=aperture_name,
                      source_offset_r=r_img, source_offset_theta=theta_img,
                      optimal_offset_r=0.0, optimal_offset_theta=0.0, trim_fov_pixels=101)
            # now loop through the offsets and angles for positions around the optimal position
            for offset in src_offsets:
                for angle in angles:
                    width = swb_width(x)
                    offset_arcsec = width * offset  # offsets in units of bar widths
                    rad = np.radians(angle)
                    # dx and dy are arcsec from the optical position for filt
                    dx = offset_arcsec * np.cos(rad)
                    dy = offset_arcsec * np.sin(rad)
                    r = np.sqrt(dx**2 + dy**2)
                    # now use the bar_offset to get the r and theta values referenced to the bar center that
                    # we need to pass to webbpsf
                    x_img = x - dx
                    r_img = np.sqrt(x_img**2 + dy**2)
                    theta_img = np.degrees(np.arctan2(dy, x_img)) - np.sign(x) * bar_angle
                    # the angle used in filenaming needs to be positive...
                    if angle < 0.0:
                        angle += 360.0
                    psf_suite(nw=nw, wmin=wmin, wmax=wmax, instrument=NIRCam,
                              outname='nircam', fov_pixels=351, aperture=aperture_name,
                              source_offset_r=r_img, source_offset_theta=theta_img,
                              optimal_offset_r=r, optimal_offset_theta=angle, trim_fov_pixels=101)
                              

if doNIRSpec:
    NIRSpec = wp.NIRSpec()
    NIRSpec.pupilopd = 'OPD_RevW_ote_for_NIRSpec_requirements.fits.gz'
    NIRSpec.pixelscale = 0.105
    NIRSpec.pupil_mask = 'NIRSpec grating'
    NIRSpec.image_mask = None #If not set to None, webbPSF will add the MSA mask (also for the IFU!). The ETC handles that separately. 
    psf_suite(
        nw=30,
        wmin=0.5,
        wmax=6.0,
        instrument=NIRSpec,
        outname='nirspec',
        fov_pixels=29,
        aperture='shutter-s200a1-s200a2-s200b1-s400a1-s1600a1',
        oversample=5) #NIRSpec is undersampled at all wavelengths (more than other instruments), so we increase the oversample here to comp.

    NIRSpec = wp.NIRSpec()
    NIRSpec.pupilopd = 'OPD_RevW_ote_for_NIRSpec_requirements.fits.gz'
    NIRSpec.pixelscale = 0.105
    NIRSpec.pupil_mask = 'NIRSpec grating'
    NIRSpec.image_mask = None
    psf_suite(nw=30, 
              wmin=0.5, 
              wmax=6.0, 
              instrument=NIRSpec,
              outname='nirspec', 
              fov_pixels=29, 
              aperture='ifu',
              oversample=5) #NIRSpec is undersampled at all wavelengths (more than other instruments), so we increase the oversample here to comp.

    NIRSpec = wp.NIRSpec()
    NIRSpec.pupilopd = 'OPD_RevW_ote_for_NIRSpec_requirements.fits.gz'
    NIRSpec.pixelscale = 0.105
    NIRSpec.pupil_mask = None
    NIRSpec.image_mask = None # We don't need the MSA grid here. The ETC does that separately
    psf_suite(nw=30, 
              wmin=0.5, 
              wmax=6.0, 
              instrument=NIRSpec,
              outname='nirspec', 
              fov_pixels=29, 
              aperture='mirror',
              oversample=5) #NIRSpec is undersampled at all wavelengths (more than other instruments), so we increase the oversample here to comp.

if doNIRISS:
    NIRISS = wp.NIRISS()
    NIRISS.pupilopd = 'OPD_RevW_ote_for_NIRISS_requirements.fits.gz'
    NIRISS.pixelscale = 0.0656
    psf_suite(nw=30, wmin=0.6, wmax=5.2, instrument=NIRISS,
              outname='niriss', fov_pixels=25, aperture='imager')
    
    NIRISS = wp.NIRISS()
    NIRISS.pupilopd = 'OPD_RevW_ote_for_NIRISS_requirements.fits.gz'
    NIRISS.pupil_mask = 'GR700XD'
    NIRISS.pixelscale = 0.0656
    psf_suite(nw=30, wmin=0.6, wmax=2.9, instrument=NIRISS,
              outname='niriss', fov_pixels=61, aperture='soss', rot90=False)
    
    NIRISS = wp.NIRISS()
    NIRISS.pupilopd = 'OPD_RevW_ote_for_NIRISS_requirements.fits.gz'
    NIRISS.pupil_mask = 'MASK_NRM'
    NIRISS.pixelscale = 0.0656
    psf_suite(nw=30, wmin=2., wmax=5.1, instrument=NIRISS,
              outname='niriss', fov_pixels=81, aperture='nrm')
