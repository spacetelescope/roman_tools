#!/usr/bin/env python

# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
rewrite_json.py - a command line tool to simply read in then write out a JSON file (correctly sorted/formatted)

Rather than overwriting the file (say abc.json), the new version is named abc.json.out.

"""

import json, os, sys


def read_json(fname):
    with open(fname) as f:
        return json.load(f)


def write_sorted_json(data, fname):
    with open(fname, 'w') as f:
        json.dump(data, f, indent=4, separators=(',', ': '), sort_keys=True)
        f.write('\n')


def run():

    # loop over each file given
    for in_fname in sys.argv[1:]:

        assert os.path.exists(in_fname), 'Input file not found: '+in_fname
        out_fname = in_fname+'.out.json'
        assert not os.path.exists(out_fname), 'Do not want to overwrite: '+out_fname

        # load the input file then write it out
        jobj = read_json(in_fname)
        write_sorted_json(jobj, out_fname)

    return 0


if __name__ == '__main__':
    # wrap run with sys.exit() so that non-zero status code will be sent on exception
    sys.exit(run())
