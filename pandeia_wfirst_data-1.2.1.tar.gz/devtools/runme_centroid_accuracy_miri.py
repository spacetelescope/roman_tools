import numpy as np
import matplotlib.pylab as plt
import matplotlib as mpl
import astropy.io.fits as fits
import time
from matplotlib.ticker import ScalarFormatter
import json

# pandeia imports
# utility functions for building calculations and sources.
from pandeia.engine.calc_utils import build_default_calc, build_default_source
# this is the core function that takes the calculation input, peforms the ETC calculation, and returns the results.
from pandeia.engine.perform_calculation import perform_calculation
import pandeia.engine.config as cf

# Read in the configuration information in order
# to get parameters for target acq
fname = cf.default_refdata()+'/jwst/miri/config.json'
fp = open(fname, 'r')
cfg_tree = json.load(fp)
fp.close()

mpl.rcParams["axes.formatter.useoffset"] = False
plt.style.use('ggplot')

# Created teh aperture / fitler / subarray combination based
# on the values listed in 
# https://github.com/STScI-SSB/pandeia/issues/2617#issuecomment-287800932
n = 10 
aperture_filter_subarray = [
        ('Time Series', 'imager', 'full', 'f560w', np.logspace(-2.5,0.3,n)),      # time series
        ('Time Series', 'imager', 'slitlessprism', 'f560w', np.logspace(-1.3,1.3,n)),      # time series
        ('Time Series', 'imager', 'full', 'f1000w', np.logspace(-2.3,0.3,n)),      # time series
        ('Time Series', 'imager', 'slitlessprism', 'f1000w', np.logspace(-2,1.4,n)),      # time series
        ('Time Series', 'imager', 'full', 'f1500w', np.logspace(-2.2,0.3,n)),      # time series
        ('Time Series', 'imager', 'slitlessprism', 'f1500w', np.logspace(-2,1.4,n)),      # time series
        ]

colors = ['ro-', 'bx-', 'gd-', 'k^-', 'cv-', 'm>-', 'y8-']

fig1 = plt.figure(1, figsize=(12, 12))
plt.show()
clf()

print('Going to loop over the aperture filter combinations...')
# swap between apertures
for ii, (thetitle, aperture, subarray, afilter, norm_fluxs) in enumerate(aperture_filter_subarray):
    sns = []
    neas = []
    print('doing {} {} {}'.format(aperture, afilter, subarray))

    plt.subplot(2,3,ii+1)

    try:
        
        for norm_flux in norm_fluxs:
            print('\tCalculating for flux {}'.format(norm_flux))
            
            # make a default calculation
            c = build_default_calc(telescope='jwst', instrument='miri', mode='target_acq', method='taphot')
            c['configuration']['instrument']['aperture'] = aperture
            c['configuration']['instrument']['filter'] = afilter
            c['configuration']['detector']['subarray'] = subarray
            c['scene'][0]['position']['x_offset'] = 0.0
            c['scene'][0]['spectrum']['normalization']['norm_flux'] = norm_flux

            # run the calculation
            rphot = perform_calculation(c, dict_report=False)

            # make a default calculation
            c = build_default_calc(telescope='jwst', instrument='miri', mode='target_acq', method='tacentroid')
            c['configuration']['instrument']['aperture'] = aperture
            c['configuration']['instrument']['filter'] = afilter
            c['configuration']['detector']['subarray'] = subarray
            c['scene'][0]['position']['x_offset'] = 0.0
            c['scene'][0]['spectrum']['normalization']['norm_flux'] = norm_flux

            # run the calculation
            rcent = perform_calculation(c, dict_report=False)

            fits_phot = rphot.as_fits()
            fits_cent = rcent.as_fits()

            print('\t\t{} {}'.format(fits_phot['scalar']['sn'],fits_cent['scalar']['extracted_noise']))

            sns.append(fits_phot['scalar']['sn'])
            neas.append(fits_cent['scalar']['extracted_noise'])

        plt.plot(sns,np.array(neas)*1000*np.sqrt(2), 'ko-')
    except:
        pass

    print('aperture {}  norm_fluxs {}  sns {}  extracted_noise {}'.format(aperture, norm_fluxs, sns, neas))

    #plt.xlim((1, 1000))
    plt.xscale('log')
    plt.yscale('log')

    if (ii+1) in [4, 5, 6]:
        plt.xlabel('Photometric SNR')
    if (ii+1) in [1, 4]:
        plt.ylabel('NEA (milli-arcsec)')
    ax = plt.gca()
    plt.title('{} {} {} {}'.format(thetitle, aperture, subarray, afilter), fontsize=10)
    #ax.xaxis.set_major_formatter(ScalarFormatter())
    #ax.yaxis.set_major_formatter(ScalarFormatter())

    fig1.canvas.draw()

plt.suptitle('MIRI', fontsize=24)
fig1.canvas.draw()

plt.savefig('centroid_accuracy_miri.pdf')

