#!/usr/bin/env python

import os

from pandeia.engine.io_utils import read_json, write_json

"""
This script parses the JSON file that contains all of the Brown et al. (2014) galaxy spectra
and outputs only those entries where 'display' is set to 'true'.
"""

datadir = os.path.join(os.environ['pandeia_refdata'], 'sed', 'galaxies')

full_cat = os.path.join(datadir, "spectra_all.json")
disp_cat = os.path.join(datadir, "spectra.json")

cat = read_json(full_cat)

out = {}

for gal in cat:
    if cat[gal]['display']:
        cat[gal].pop('display')
        out[gal] = cat[gal]

write_json(out, disp_cat)
