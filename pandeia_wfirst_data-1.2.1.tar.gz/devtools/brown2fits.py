#!/usr/bin/env python

import os
import sys

import pysynphot as psyn
import astropy.io.fits as fits
from astropy.table import Table

"""
This script is used to convert the ASCII data files provided by Brown et al. and convert them
to pysynphot-compatible FITS binary tables.  It is to be run in the same directory as the Brown data
files.
"""
files = [f for f in os.listdir('.') if ".dat" in f]

for file in files:
    outfile = file.replace(".dat", ".fits").lower()
    t = Table.read(file, format='ascii')
    wave = t['col1']
    flam = t['col2']

    sp = psyn.ArraySpectrum(wave, flam, waveunits='angstroms', fluxunits='flam')

    sp.writefits(outfile, precision="double")
