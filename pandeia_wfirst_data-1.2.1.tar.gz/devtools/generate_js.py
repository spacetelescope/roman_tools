#!/usr/bin/env python
#
import copy, glob, json, os, sys, time

# Support Python 3.*
PY3K = sys.version_info[0] > 2
if PY3K:
   unicode = str # define "unicode" type where it is no longer needed

# Global constants
SUPPORTED_JWST_MODES = {
    "miri":    ["coronagraphy", "imaging", "lrsslit", "lrsslitless", "mrs", "target_acq"],
    "nircam":  ["coronagraphy", "lw_imaging", "ssgrism", "sw_imaging", "wfgrism", "target_acq"],
    "niriss":  ["ami", "imaging", "soss", "wfss", "target_acq"],
    "nirspec": ["fixed_slit", "ifu", "msa", "target_acq"],
}
JWST_CONSTRAINED_MODES = ['miri_coronagraphy','miri_target_acq',
                          'nircam_coronagraphy','nircam_target_acq',
                          'niriss_target_acq',
                          'nirspec_fixed_slit', 'nirspec_target_acq']
JWST_DISPERSER_MODES   = ['miri_lrsslit', 'miri_lrsslitless', 'miri_mrs', 'nircam_ssgrism',
                          'nircam_wfgrism', 'niriss_soss', 'niriss_wfss']
JWST_DISPFILT_MODES    = ['nirspec_fixed_slit','nirspec_ifu','nirspec_msa']
JWST_MULTIORDER_MODES  = ['niriss_soss']

JWST_SPEC_MODENAMES    = ['fixed_slit','ifu','lrsslit','lrsslitless','mrs','msa','soss','ssgrism','wfgrism','wfss']

# Strategy names permitted in the engine which are not supported in the UI
NON_UI_STRATEGIES = ['ifuapphot','tacentroid']

# Strategy names-to-letter mapping.  This convention only used in the UI (for now).
JWST_STRATEGY_LETTERS = {
    "imagingapphot":  "a",
    "specapphot":     "b",
    "msafullapphot":  "c",
    "coronagraphy":   "d",
    "ifunodinscene":  "e",
    "ifunodoffscene": "f",
    "soss":           "g",
    "taphot":         "h",
}

# Due to the way our data and data constraints are laid out in the config files, we might have
# aperture constraints shared by multiple instr_mode values, and this can cause the constraints
# sanity-checker to try to sanity-check combinations that aren't even possible in the UI.
# So we list here any such impossible combinations that the sanity checker might nevertheless
# try to use and then get snagged on.
# Here is one such example (user cannot select a filter by itself, with nirspec_fixed_slit).
IGNORE_CONSTRAINT_SANITY_CHECKS = [
    ('nirspec_fixed_slit', 'filters'),
]

def strip_meta(d):
    """
    recursively strip any 'meta' tags from a dict, d. this function modifies the dict in place.
    """
    if isinstance(d, dict):
        if 'meta' in d:
            d.pop('meta')
        for k in d.keys():
            strip_meta(d[k])


def hack_hst_cfg(request, inst_mode=''):
    """ put this HACK in place until the HST stuff is worked out """
    if request == 'instruments':
        return ['wfc3', 'acs', 'nicmos'] # ['acs','wfc3']
    if request == 'modes':
        return {'wfc3': ['ir', 'uvis1'], 'acs': ['wfc1'], 'nicmos': ['2']};
#       return {'acs': ['hrc','sbc','wfc1'], 'wfc3': ['uvis1','uvis2']};
    if request == 'filters':
        if inst_mode == 'acs,hrc': return ['f220w','f330w','f658n','f850lp','f892n']
        if inst_mode == 'acs,sbc': return ['f122m','f125lp','f140lp','f165lp']
        if inst_mode == 'acs,wfc1': return ['f435w','f550m','f606w','f658n','f814w','f850lp','f892n']
        if inst_mode == 'wfc3,uvis1': return ['f225w','f275w','f300x','f336w','f350lp','f438w','f555w','f606w','f656n','f673n','f814w','f850lp']
        if inst_mode == 'wfc3,uvis2': return ['f225w','f275w','f300x','f336w','f350lp','f438w','f555w','f606w','f656n','f673n','f814w','f850lp']
    raise RuntimeError('how did we get here?')


def dict_to_str(adict):
    """ get around the unicode issue without requiring yaml, etc. """
    retval = '{'
    for item in sorted(adict.keys()):
        val = adict[item]
        if type(val) == dict:
            retval += "'"+item+"':"+dict_to_str(val)+','
        elif type(val) == list:
            retval += "'"+item+"':"+list_to_str(val)+','
        elif type(val) in (str, unicode):
            retval += "'"+item+"':'"+val+"',"
        else:
            retval += "'"+item+"':"+str(val)+','
    if "," in retval:
        retval = retval[:-1] # rm final comma
    return retval+'}'


def list_to_str(alist):
    """ get around the unicode issue without requiring yaml, etc. """
    # do the job of "str()" without dealing with unicode issues
    retval = "["
    for item in alist:
        if type(item) in (int, float):
            retval += str(item)+","
        else:
            retval += "'"+str(item)+"',"
    if "," in retval:
        retval = retval[:-1] # rm final comma
    return retval + "]"


def listlist_to_str(alist, spaces=True):
    """ see notes in list_to_str """
    retval = '[ '
    for item in alist:
        retval += list_to_str(item)+','
    if len(list(alist)):
        retval = retval[:-1] # rm final comma
    retval += ' ]'
    if not spaces:
        retval = retval.replace(' ','')
    return retval


def listdict_to_str(adict):
    """ get around the unicode issue without requiring yaml, etc. """
    retval = '{'
    for item in sorted(adict.keys()):
        retval += "'"+item+"': "+list_to_str(adict[item])+','
    if "," in retval:
        retval = retval[:-1] # rm final comma
    return retval+'}'


def find_disp_str(disp_str_dict, itemname, secondary_key=None):
    """ Convenience - do a simple lookup in the dict but also cleanly handle
    when/if the disp_str_dict is absent, or doesn't contain itemname. If a secondary_key
    is provided and the display_string is actually a dict, then use it to lok up a value. """
    # if no possible display string, use key name itself, uppercased
    if disp_str_dict==None:
        return str(itemname).upper()

    if 'display_string' in disp_str_dict:
        val = disp_str_dict['display_string']
        if type(val) == dict:
            if secondary_key in val:
                return val[secondary_key];
            elif 'default' in val:
                return val['default']
            else:
                raise ValueError('display_string is mal-formed dict: '+str(val))
        else:
            return val

    elif itemname in disp_str_dict:
        return disp_str_dict[itemname]
    else:
        return str(itemname).upper()


def read_full_file(fname):
    """ convenience function """
    assert os.path.exists(fname), 'read_full_file expected, but did not find file named: '+fname
    f = open(fname, 'r')
    buf = f.read()
    f.close()
    return buf


def generate_all_cfg_js(pandeia_data_loc, output_dir):
    """ Given the values found in json config files under
    pandeia_data, generate all needed javascript files for
    the client, dumping them into output_dir.
    """

    # init
    instruments = sorted(SUPPORTED_JWST_MODES.keys())

    # collect items
    supported_lines = []

    aperture_lines = []
    constraint_lines = []
    dsprsr_lines = []
    enum_lines = []
    filter_lines = []
    normalzn_lines = []
    range_lines = []
    readmode_lines = []
    sed_lines = []
    shutlocs_lines = []
    sizes_lines = []
    slitlet_lines = []
    strategy_lines = []
    stratname_lines = []
    subarray_lines = []
    extinct_lines = []
    exposure_conf_lines = []

    # meta info - can use simple conversion via str() here
    supported_lines.append("CFG_VALS.SUPPORTED_jwst_instruments = "+str(instruments)+';')
    supported_lines.append("CFG_VALS.SUPPORTED_jwst_modes = "+dict_to_str(SUPPORTED_JWST_MODES)+';')
    supported_lines.append("CFG_VALS.SUPPORTED_jwst_spec_modenames = "+str(JWST_SPEC_MODENAMES)+';')

    # JWST: loop through all supported instruments and modes
    for instr in instruments:

        # open the instrument config file
        fname = pandeia_data_loc+'/jwst/'+instr+'/config.json'
        cfg_tree = json.loads(read_full_file(fname))
        assert type(cfg_tree) == dict, 'Unexpected json layout in: '+fname
        strip_meta(cfg_tree)

        # Grab values required for front-end exposure time calculations
        line = "CFG_VALS.SUBARRAYS_CONF_jwst_{} = {};".format(instr, dict_to_str(cfg_tree['subarray_config']))
        exposure_conf_lines.append(line)

        line = "CFG_VALS.RAMP_CONF_jwst_{} = {};".format(instr, dict_to_str(cfg_tree['ramp_config']))
        exposure_conf_lines.append(line)

        line = "CFG_VALS.READMODE_CONF_jwst_{} = {};".format(instr, dict_to_str(cfg_tree['readmode_config']))
        exposure_conf_lines.append(line)

        # aperture/shutter/slit/etc sizes
        # cfg_tree['aperture_config']['shutter']
        if 'aperture_config' in cfg_tree:
            aper_tree = cfg_tree['aperture_config']
            # Get info on any instrument that has a shutter
            if 'shutter' in aper_tree:
                height = aper_tree['shutter']['xdisp']
                width  = aper_tree['shutter']['disp']
                sizes_lines.append("CFG_VALS.SIZES_jwst_"+instr+"_shutter_height = "+str(height)+";")
                sizes_lines.append("CFG_VALS.SIZES_jwst_"+instr+"_shutter_width = "+str(width)+";")

                # Read shutter cfg file
                fname2 = pandeia_data_loc+'/jwst/'+instr+'/shutters.json'
                shutter_tree = json.loads(read_full_file(fname2))
                strip_meta(shutter_tree)
                shutlocs = [ [k,shutter_tree[k]['display_string']] for k in sorted(shutter_tree.keys()) ]
                shutlocs_lines.append("CFG_VALS.SHUTTER_LOCS_jwst_"+instr+" = "+listlist_to_str(shutlocs)+';')

        # mode-specific items
        for mode in sorted(SUPPORTED_JWST_MODES[instr]):
            # basics
            instr_mode = instr+'_'+mode

            # mode config sub-dict
            mode_cfg = {}
            if 'mode_config' in cfg_tree:
                mode_cfg = cfg_tree['mode_config'][mode]

            # readmode
            where2look = mode_cfg if 'readmodes' in mode_cfg else cfg_tree
            rdmd_info = [ [rdmd,find_disp_str(cfg_tree['readmode_config'][rdmd],rdmd,mode)] for rdmd in where2look['readmodes'] ]
            line = "CFG_VALS.READMODES_jwst_"+instr+'_'+mode+" = "+listlist_to_str(rdmd_info)+';'
            readmode_lines.append(line)

            # subarray
            where2look = mode_cfg if 'subarrays' in mode_cfg else cfg_tree
            # Use "default" only here for now since _this_ CFG_VALS entry is only used in the UI for having the
            # full per-inst_mode list of subarrays (doesn't depend on readmode).  Note however that SUBARRAYS_CONF_* has
            # the full tree of readmode-dependent information on subarrays
            sbry_info = [ [sbry,find_disp_str(cfg_tree['subarray_config']['default'][sbry],sbry,mode)] for sbry in where2look['subarrays'] ]
            line = "CFG_VALS.SUBARRAYS_jwst_"+instr+'_'+mode+" = "+listlist_to_str(sbry_info)+';'
            subarray_lines.append(line)

            # enumerated time items (optional)
            for itemname, capname in [('enum_nexps','NEXPS'),('enum_ngroups','NGROUPS'),('enum_nints','NINTS')]:
                where2look = mode_cfg if itemname in mode_cfg else cfg_tree
                if itemname in where2look:
                    enum_item_info = [ [item, str(item)] for item in sorted(where2look[itemname], key=lambda n: float(n)) ]
                    line = 'CFG_VALS.'+capname+'_jwst_'+instr+'_'+mode+' = '+listlist_to_str(enum_item_info)+';'
                    enum_lines.append(line)

            # constraints (e.g. miri coronagraphy)
            if instr_mode in JWST_CONSTRAINED_MODES and 'config_constraints' in cfg_tree:
                apertures = mode_cfg['apertures']
                constraint_tree = cfg_tree['config_constraints']['apertures']

                # NOTE - Sanity Check all constraints !
                # We actually force that all aperture values from "apertures" MUST exist in the
                # constraint_tree for a given thing (e.g. filters), or no apertures at all for that
                # thing, bc otheriwse the JS logic in the UI (selected_aperture() func) becomes too unwieldy
                for constrained_thing in ['filters','readmodes','subarrays']: # add dispersers later? (needs work)
                    constrained_thing_keys = [k for k in constraint_tree if constrained_thing in constraint_tree[k]]
                    if constrained_thing_keys == [] or \
                       (instr_mode, constrained_thing) in IGNORE_CONSTRAINT_SANITY_CHECKS or \
                       set(apertures).issubset(constrained_thing_keys):
#                       print('Constraints seem sane/correct for: '+instr_mode+'/'+constrained_thing)
                        pass
                    else:
                        # the constraints for this (instr_mode, thing) need to be checked and may have a self-consistency issue ...
                        if len(constrained_thing_keys) > 0 and set(constrained_thing_keys).issubset(apertures):
                            # ahh - simple case - we are missing choice-lists for some apers, and so we
                            # can simply/safely populate with the mode_config set of choices
                            keys_missing_constraints = tuple(set(apertures) - set(constrained_thing_keys))
                            all_choices_for_thing = mode_cfg[constrained_thing]
                            print('INFO: handling sparsely-populated constraints: '+instr_mode+'/'+constrained_thing+' ...')
#                           print('we will now allow each of these apertures: '+str(keys_missing_constraints))
#                           print('to each use all of these "'+constrained_thing+'" choices: '+str(all_choices_for_thing))
                            # Here we are actually adding to the constraint_tree read from the config file (but

                            # of course not editing the config file), to fill in missing choices for sparsely-populated
                            # constraint information.  If an instr_mode is NOT constrained, it gets all valid choices
                            # of "thing" (e.g. subarray) from mode_config.
                            for key_missing_constraints in keys_missing_constraints:
                                assert key_missing_constraints not in constraint_tree, '??? cant happen, see above ???'
                                constraint_tree[key_missing_constraints] = {constrained_thing: {'default': all_choices_for_thing}}
#                               print('Added '+constrained_thing+' constraint for: '+key_missing_constraints+ \
#                                     ':\n\t'+str(constraint_tree[key_missing_constraints]))
                        else:
                            raise ValueError('Problem with '+instr_mode+' constraints on: '+constrained_thing+ \
                                             '\nFull aper list:  '+str(sorted(apertures))+ \
                                             '\nconstraint keys: '+str(sorted(constrained_thing_keys))+ \
                                             '\n\nwhole constraint dict: '+str(constraint_tree) )

                # "matches" is the dict we primarily work with here, but it currently shares references
                # with cfg_tree; since we are going to modify matches in place, but don't want to
                # modify cfg_tree or mode_cfg, we make a deep copy of it and use that instead.
                matches = copy.deepcopy({k:constraint_tree[k] for k in apertures})
                # add the display_string info - modify dict in place
                for k in list(matches.keys()): # modifying dict so copy keys
                    matches[k]['display_string'] = find_disp_str(aper_tree[k], k, mode)
                # also resolve some of the values (where we usu. expect lists) to see if they set a level
                # lower so they can vary by ins.mode (if so, collapse to just lists using ins.mode);
                # modify dict in place
                for k in list(matches.keys()): # modifying dict so copy keys
                    this_apers_constraints = matches[k]
                    for constraint_name in list(this_apers_constraints.keys()): # modifying dict so copy keys
                        constraint_val = this_apers_constraints[constraint_name]
                        # here is where we resolve the choice and reduce the tree by a level
                        if type(constraint_val) == dict:
                            if mode in constraint_val:
                                new_val = constraint_val[mode]
                            elif 'default' in constraint_val:
                                new_val = constraint_val['default']
                            else:
                                raise ValueError('constraint sub-dict is a mal-formed dict: '+str(constraint_val))
                            # Check for the USE-THEM-ALL flag by seeing if they set this val to null/None
                            if new_val == None:
                                # they said "null", which means "no constraint", so use the list (e.g. of filters)
                                # which applies to the entire mode (independently of aperture)
                                if constraint_name in mode_cfg:
                                    new_val = mode_cfg[constraint_name]
                                else:
                                    # at this point (e.g. say for filters) we would need to check if the global
                                    # instrument-level (file-level) list is set and use that; add that code here
                                    raise ValueError('constraint "'+constraint_name+ \
                                          '" needs a fallback set of choices but none were found in mode_config')
                            # dict update
                            this_apers_constraints[constraint_name] = new_val
                    # update the matches dict
                    matches[k] = this_apers_constraints
                # done
                line = "CFG_VALS.CONSTRAINTS_jwst_"+instr_mode+" = "+dict_to_str(matches)+';'
                constraint_lines.append(line)

            # apertures - see if there are specific apertures allowed for this mode
            valid_apertures = []
            if 'apertures' in mode_cfg:
                valid_apertures = mode_cfg['apertures']
                aperinfo = [ [a, find_disp_str(aper_tree[a], a, mode)] for a in valid_apertures ]
                line = "CFG_VALS.APERTURES_jwst_"+instr_mode+" = "+listlist_to_str(aperinfo)+';'
                aperture_lines.append(line)

            # wavelength ranges (filter, disperser, etc)
            if mode in JWST_SPEC_MODENAMES and 'range' in cfg_tree and len(valid_apertures)>0:
                for va in valid_apertures:
                    ranges = cfg_tree['range'][va] # exists in cfg stuff as a dict
                    # get the range keys for this aper, do not include the aper-wide fallback values
                    range_keys = [k for k in ranges.keys() if k not in ('wmin','wmax')]

                    # if there are keys in the range_keys list, create a dict; if not, there is a single name-less key in the dict
                    if len(range_keys):
                        # random spot-check
                        assert ranges[range_keys[0]]['wmax'] > ranges[range_keys[0]]['wmin'], 'Invalid wmin,wmax: '+str(ranges[range_keys[0]])
                        # get arrays of ranges, in keyed dicts (key if usu. filter name but varies by mode)
                        range_arrays = { k : [ranges[k]['wmin'], ranges[k]['wmax']] for k in range_keys }
                    else:
                        # in this case ranges had ONLY the fallback values
                        assert ','.join(sorted(ranges.keys())) == 'wmax,wmin', 'Unexpected ranges object: '+str(ranges)
                        range_arrays = { '': [ranges['wmin'],ranges['wmax']] }

                    if instr_mode in JWST_MULTIORDER_MODES:
                        # If multi-order, then the current keys of range_arrays are "<dispersername>_<ordernumber>", but we want
                        # to only use order number as the keys to this info. So we lop off the first part of each key
                        # name (e.g. turn "gr700xd_2" into "2"), but before we do, make sure all the key names start with
                        # the same disperser name (e.g. "gr700xd"). If not, we have to revamp this logic.
                        assert len(set([k.split('_')[0] for k in range_arrays])) == 1, 'Unexpected orders from multiple different dispersers: '+str(ranges)
                        range_arrays = {k.split('_')[-1]:range_arrays[k] for k in range_arrays}

                    line = "CFG_VALS.WAVE_RANGES_jwst_"+instr_mode+'_'+va+' = '+dict_to_str(range_arrays)+';'
                    range_lines.append(line)

            # filters: is a listlist to preserve key order; is why we can't make it a dict/Obj { filtval: display_str, ... }
            filtinfo = []
            dispinfo = []
            if instr_mode in JWST_DISPERSER_MODES:
                where2look = mode_cfg if 'dispersers' in mode_cfg else cfg_tree
                if 'disperser_config' in cfg_tree:
                    dispinfo = [ [g, find_disp_str(cfg_tree['disperser_config'][g], g)] for g in where2look['dispersers'] ]
                else:
                    dispinfo = [ [g, g.upper()]                                         for g in where2look['dispersers'] ]
                line = "CFG_VALS.DISPERSERS_jwst_"+instr_mode+" = "+listlist_to_str(dispinfo)+';'
                dsprsr_lines.append(line)
            if instr_mode in JWST_DISPFILT_MODES:
                if 'config_constraints' in cfg_tree:
                    dispcfg = cfg_tree['config_constraints']['dispersers']
                    for disp in [d for d in sorted(dispcfg.keys()) if 'filters' in dispcfg[d]]:
                        for filt in dispcfg[disp]['filters']:
                            disp_string = disp.upper() if 'disperser_config' not in cfg_tree else cfg_tree['disperser_config'][disp]['display_string']
                            filt_string = filt.upper() if    'filter_config' not in cfg_tree else cfg_tree['filter_config'][filt]['display_string']
                            filtinfo.append( [disp+','+filt, disp_string+'/'+filt_string] )
            else:
                if 'filter_config' in cfg_tree:
                    filtinfo = [ [f, find_disp_str(cfg_tree['filter_config'][f], f, mode)] for f in mode_cfg['filters'] ]
                else:
                    filtinfo = [ [f, f.upper()]                                            for f in mode_cfg['filters'] ]

            line = "CFG_VALS.FILTERS_jwst_"+instr_mode+" = "+listlist_to_str(filtinfo)+';'
            filter_lines.append(line)

            # strategies
            stratcfg = cfg_tree['strategy_config'][mode]
            line = "CFG_VALS.STRATEGIES_"+instr_mode+" = "+ \
                   list_to_str([s for s in stratcfg['permitted_methods'] if s not in NON_UI_STRATEGIES])+';'
            strategy_lines.append(line)

            # slitlets
            if 'slitlet_shapes' in mode_cfg:
                slitletshapeinfo = mode_cfg['slitlet_shapes']

                slitshape_strings = []
                try:
                    for k,v in slitletshapeinfo:
                        slitshape_strings.append([str(k).replace(' ', ''), str(v)])
                except:
                    # format is broken currently for NIRSpec TA - use empty list
                    pass

                slitlet_lines.append("CFG_VALS.SLITLETS_jwst_"+instr_mode+" = "+str(slitshape_strings)+';')
                # note, values in nirspec file generated via:
                #   orig = ['-2,-1,0,1,2', '-2,-1,0,1', '-2,0,2', '-1,0,1', '-1,0', '0']
                #   [ [[[0,int(j)] for j in i.split(',')], i] for i in orig]
                #   NOTE that display_string is baked right in here, not a dict key ...

    # HST: loop through all supported modes (types->hst->bandpasses)
    # NOTE - the HST info is currently kindof hacked - needs to be revisited !!!
    SUPPORTED_HST_INSTRUMENTS = hack_hst_cfg('instruments')
    supported_lines.append("CFG_VALS.SUPPORTED_hst_instruments = "+list_to_str(SUPPORTED_HST_INSTRUMENTS)+';')
    SUPPORTED_HST_MODES = hack_hst_cfg('modes')
    supported_lines.append("CFG_VALS.SUPPORTED_hst_modes = "+listdict_to_str(SUPPORTED_HST_MODES)+';')

    fname = pandeia_data_loc+'/normalization/config.json'
    cfg_tree = json.loads(read_full_file(fname))
    assert type(cfg_tree) == dict, 'Unexpected json layout in: '+fname
    assert 'types' in cfg_tree
    assert 'hst' in cfg_tree['types']
    assert 'bandpasses' in cfg_tree['types']['hst']
    bpdict = cfg_tree['types']['hst']['bandpasses']
    bandpasses = [b for b in sorted(bpdict.keys()) if 'display_string' in bpdict[b]]

    bp_collection_dict = {}
    for bp in bandpasses:
        bpinst,   bpmode,   bpfilt    = bp.split(',')
        bpinst_ds,bpmode_ds,bpfilt_ds = bpdict[bp]['display_string'].split('/')

        assert bpinst in SUPPORTED_HST_INSTRUMENTS
        assert bpmode in SUPPORTED_HST_MODES[bpinst]
        key = 'FILTERS_hst_'+bpinst+'_'+bpmode
        if key in sorted(bp_collection_dict.keys()):
            bp_collection_dict[key].append([bpfilt,bpfilt_ds])
        else:
            bp_collection_dict[key] = [ [bpfilt,bpfilt_ds], ]

    for key in sorted(bp_collection_dict.keys()):
        line = "CFG_VALS."+key+" = "+listlist_to_str(bp_collection_dict[key])+';'
        filter_lines.append(line)

    # Normalization values used by the UI
    fname = pandeia_data_loc+'/normalization/config.json'
    cfg_tree = json.loads(read_full_file(fname))
    assert type(cfg_tree) == dict, 'Unexpected json layout in: '+fname
    systems = sorted(cfg_tree['types']['photsys']['bandpasses'].keys())
    systemsinfo = [ [s, find_disp_str(cfg_tree['types']['photsys']['bandpasses'][s],s) ] for s in systems]
    normalzn_lines.append("CFG_VALS.NORM_photsys = "+listlist_to_str(systemsinfo)+';')
    for sstm in systems:
        filts = [str(f) for f in sorted(cfg_tree['types']['photsys']['bandpasses'][sstm].keys()) if f != 'display_string']
        # added str() call in list comprehension above to rm unicode-ness for py2
        # now sort by photometric system passbands
        ordered_filts = sorted(filts, key=lambda x: "ubvgrizyjhklmnq".find(x.lower()[0]))
        filtinfo = [ [f,cfg_tree['types']['photsys']['bandpasses'][sstm][f]['display_string']] for f in ordered_filts]
        normalzn_lines.append("CFG_VALS.NORM_photsys_"+sstm+" = "+listlist_to_str(filtinfo)+';')
    unitsinfo = [ [u, u] for u in cfg_tree['defaults']['fluxunits'] ]
    normalzn_lines.append("CFG_VALS.NORM_fluxunits = "+listlist_to_str(unitsinfo)+';')
    unitsinfo = [ [u, u] for u in cfg_tree['types']['at_lambda']['defaults']['fluxunits'] ]
    normalzn_lines.append("CFG_VALS.NORM_at_lambda_fluxunits = "+listlist_to_str(unitsinfo)+';')
    unitsinfo = [ [u, u] for u in cfg_tree['defaults']['waveunits'] ]
    normalzn_lines.append("CFG_VALS.NORM_waveunits = "+listlist_to_str(unitsinfo)+';')

    # SED values used by the UI
    fname = pandeia_data_loc+'/sed/config.json'
    cfg_tree = json.loads(read_full_file(fname))
    assert type(cfg_tree) == dict, 'Unexpected json layout in: '+fname
    families = [sf for sf in sorted(cfg_tree['sed_families'].keys()) if 'display_string' in cfg_tree['sed_families'][sf]]


    familiesinfo = [ [s, find_disp_str(cfg_tree['sed_families'][s],s) ] for s in families]
    sed_lines.append("CFG_VALS.SED_families = "+listlist_to_str(familiesinfo)+';')
    for fam in families:
        sedtypes = cfg_tree['sed_families'][fam]['sed_types']  # e.g. for fam=analytics, sedtypes=["flat", "powerlaw", "blackbody", "no_continuum"]
        typesinfo = [ [st, find_disp_str(cfg_tree['sed_types'][st],st) ] for st in sedtypes ]
        sed_lines.append("CFG_VALS.SED_family_"+fam+" = "+listlist_to_str(typesinfo)+';')
        for sedtyp in sedtypes:
            if 'spectra' in cfg_tree['sed_types'][sedtyp]:
                # open and read this spectra config file
                fname = pandeia_data_loc+'/sed/'+cfg_tree['sed_types'][sedtyp]['spectra']['config']
                spec_cfg_tree = json.loads(read_full_file(fname))
                assert type(spec_cfg_tree) == dict, 'Unexpected json layout in: '+fname
                # sort keys by "Oh Be A Fine Girl, Kiss Me" (google it, I dare ya)
                ordered_keys = sorted(spec_cfg_tree.keys())
                if sedtyp == "phoenix":
                    # 3 steps to get a deterministic sort the way we want it:
                    # 1) first order by alpha (and rm unicode-ness for py2)
                    keys_by_abc = sorted([str(k) for k in spec_cfg_tree.keys()], key=lambda k: str(spec_cfg_tree[k]))
                    # 2) then order by descending "teff"
                    # (also involve the log_g value as a tiny effect to break ties (make deterministic) when two items have same teff)
                    keys_by_teff = sorted(keys_by_abc, key=lambda k: spec_cfg_tree[k]['teff']+((100.-spec_cfg_tree[k]['log_g'])/1000.), reverse=True)
                    # 3) now sort first by OBA... w/ teff as secondary (and alpha as tertiary)
                    ordered_keys = sorted(keys_by_teff, key=lambda x: "obafgkm".find(x.lower()[0]))
                specsinfo = [ [s, find_disp_str(spec_cfg_tree[s],s) ] for s in ordered_keys if 'display_string' in spec_cfg_tree[s]]
                sed_lines.append("CFG_VALS.SED_spectra_"+sedtyp+" = "+listlist_to_str(specsinfo)+';')

    # Strategy official names
    stnms = {}
    stltr = {}
    for stratfname in glob.glob(pandeia_data_loc+'/strategy/*.json'):
        strat_short = os.path.splitext(os.path.basename(stratfname))[0]
        strat_tree = json.loads(read_full_file(stratfname))
        strat_name = strat_tree['display_string']
        stnms[strat_short] = strat_name
        if strat_short not in NON_UI_STRATEGIES:
            stltr[strat_short] = JWST_STRATEGY_LETTERS[strat_short]
    stratname_lines.append("CFG_VALS.STRATEGY_NAMES = "+dict_to_str(stnms)+';')
    stratname_lines.append("CFG_VALS.STRATEGY_LETTERS = "+dict_to_str(stltr)+';')

    # Extinction information
    fname = pandeia_data_loc + '/extinction/config.json'
    cfg_tree = json.loads(read_full_file(fname))

    law_families = list(zip(sorted(cfg_tree['law_families']),
                       [cfg_tree['law_families'][x]['display_string']
                        for x in sorted(cfg_tree['law_families'])]))

    extinct_lines.append("CFG_VALS.EXTINCT_law_family = {};".format(
        listlist_to_str(law_families)))

    law_types = list(zip(sorted(cfg_tree['laws']),
                    [cfg_tree['laws'][x]['display_string']
                     for x in sorted(cfg_tree['laws'])]))

    for fam_id, fam_label in law_families:
        law_list = [x for x in law_types if x[0] in cfg_tree['law_families'][
            fam_id]['law_types']]

        extinct_lines.append("CFG_VALS.EXTINCT_law_family_{} = {};".format(
            fam_id, listlist_to_str(law_list)))

    # sort by photometric system. e.g. "vjhk"
    sorted_bandpasses = sorted(cfg_tree['bandpasses'], key=lambda x: "ubvgrizyjhklmnq".find(x.lower()[0]))
    bands = list(zip(sorted_bandpasses,
                [cfg_tree['bandpasses'][x]['display_string'] for x in sorted_bandpasses]))

    extinct_lines.append("CFG_VALS.EXTINCT_bandpasses = {};".format(
        listlist_to_str(bands)))

    # NOW just write it all out...

    # write header of CFG_VALS file
    cfg_out_nm = output_dir+'/config_values.js'
    assert not os.path.exists(cfg_out_nm), 'Will not overwrite: '+cfg_out_nm
    cfg_out = open(cfg_out_nm, 'w')

    cfg_out.write('//'+80*'-'+'\n')
    cfg_out.write('// DO NOT EDIT!  This file is generated via "pandeia_data/devtools/generate_js.py"\n')
    cfg_out.write('// (create & copy this file, output by generate_js.py, into pandeia/ui/client/js)\n')
    cfg_out.write('// DO NOT EDIT!\n')
    cfg_out.write('//'+80*'-'+'\n') # -----------------------------------------------------------------------

    cfg_out.write('\nvar CFG_VALS = {};\n')

    cfg_out.write('\n// Creation data:\n')
    cfg_out.write("CFG_VALS.CREATED_time_asc = '"+time.asctime()+"';\n")
    cfg_out.write("CFG_VALS.CREATED_time_float = "+str(time.time())+';\n')
    cfg_out.write("CFG_VALS.CREATED_from_data = '"+pandeia_data_loc+"';\n")
    cfg_out.write("CFG_VALS.CREATED_orig_name = '"+cfg_out_nm+"';\n")

    cfg_out.write('\n//'+80*'-'+'\n') # -----------------------------------------------------------------------

    cfg_out.write('\n// What is supported:\n')
    for line in supported_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n//'+80*'-'+'\n') # -----------------------------------------------------------------------

    cfg_out.write('\n// Readmode values: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in readmode_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Subarray values: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in subarray_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Time value enumerated choices: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in enum_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Physical sizes:\n')
    for line in sizes_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Constraints: each is a dict of dicts, top level key is aperture\n')
    for line in constraint_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Aperture values: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in aperture_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Disperser values: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in dsprsr_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Filter values: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in filter_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Wavelength ranges (telescope_instr_mode_aperture): each line is a dict of: { filt/disp1: [wmin, wmax], filt/disp2: ... }\n')
    for line in range_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Shutter location choices: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in shutlocs_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Slitlet choices: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in slitlet_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n//'+80*'-'+'\n') # -----------------------------------------------------------------------

    cfg_out.write('\n// Permitted strategies:\n')
    for line in strategy_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Strategy names:\n')
    for line in stratname_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n//'+80*'-'+'\n') # -----------------------------------------------------------------------

    cfg_out.write('\n// Normalization photsys: each is a list of lists: [ [value1,display_string1], [v2,ds2], ...]\n')
    for line in normalzn_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// SED "families" (list of lists)\n')
    for line in sed_lines: cfg_out.write(line+'\n')

    cfg_out.write('\n// Extinction values\n')
    for line in extinct_lines: cfg_out.write(line + '\n')

    cfg_out.write('\n// Exposure calculation reference values\n')
    for line in exposure_conf_lines: cfg_out.write(line + '\n')

    # done
    cfg_out.close()


def usage():
    print(sys.argv[0]+' <path-to-pandeia_data> [-h (for help)]')
    sys.exit(0)


#
# main routine
#
if __name__=='__main__': # in case something else imports this file


    if '-h' in sys.argv:
        usage()

    if len(sys.argv) > 1:
        data_dir = sys.argv[1]
    else:
        data_dir = os.environ['pandeia_refdata']

    pandeia_data_loc = os.path.realpath(data_dir)
    output_dir = os.getcwd()
    generate_all_cfg_js(pandeia_data_loc, output_dir)

    sys.exit(0)
