#!/usr/bin/env python
#
import glob, json, os, sys


# Support Python 3.*
PY3K = sys.version_info[0] > 2
if PY3K:
   unicode = str # define "unicode" type where it is no longer needed

# Global constants
SUPPORTED_JWST_INSTRUMENTS = ['miri', 'nircam', 'niriss', 'nirspec']
TELESCOPE = 'jwst'


def read_full_file(fname):
    """ convenience function """
    assert os.path.exists(fname), 'read_full_file expected, but did not find file named: '+fname
    f = open(fname, 'r')
    buf = f.read()
    f.close()
    return buf


def main(pandeia_data_loc):
    """ main """
    # Instrument by instrument, find any files (e.g. FITS) in the instrument sub-dirs
    # which are not used according to the JSON config file.
    for inst in SUPPORTED_JWST_INSTRUMENTS:
        print('\n\nUNUSED FILES FOR: '+inst)
        inst_dir = pandeia_data_loc+'/'+TELESCOPE+'/'+inst

        # cfg_tree
        config_file = inst_dir+'/'+'config.json'
        assert os.path.exists(config_file), 'Cannot find: '+config_file
        cfg_tree = json.loads(read_full_file(config_file))
        assert type(cfg_tree) == dict, 'Unexpected json layout in: '+config_file
        paths_dict = cfg_tree['paths']
        assert type(paths_dict) == dict, 'Unexpected json layout for paths in: '+config_file
#       paths_values = paths_dict.values()
        paths_values = [paths_dict[k] for k in paths_dict if k != 'meta']

        # first, run sanity check that all files listed in paths_values are in fact installed in inst_dir
        for pv in sorted(paths_values):
            full_fname = inst_dir+'/'+pv
#           print(full_fname)
            assert os.path.exists(full_fname), 'File listed in config.json not found on disk! : '+full_fname

        # get list of subdirs (e.g. blaze, filters, psfs)
        subdirs = glob.glob(inst_dir+'/*')
        subdirs = [s for s in subdirs if os.path.isdir(s) and not s.endswith('/psfs') and not s.endswith('/xtras')]

        # loop through subdir checking files in it
        for subdir in subdirs:
            flist = glob.glob(subdir+'/*.fits')
            # check each file now
            for full_fname in flist:
                assert full_fname.startswith(inst_dir), 'programming error - we are going to remove this part'
                part_fname = full_fname[len(inst_dir)+1:] # e.g. dispersion/jwst_miri_ch4-medium_disp_20160927151608.fits
                # if the part_fname is NOT in paths_dict, then it is outdated/unused (if our logic is correct!)
                if part_fname not in paths_values:
                    print('git rm '+part_fname) # is unused -> make it easy to act on this decision by using output


def usage():
    print(sys.argv[0]+' <path-to-pandeia_data> [-h (for help)]')
    sys.exit(0)


#
# main routine
#
if __name__=='__main__': # in case something else imports this file

    if '-h' in sys.argv:
        usage()

    if len(sys.argv) == 2:
        data_dir     = sys.argv[1]
    else:
        usage()

    main(os.path.realpath(data_dir))

    sys.exit(0)
