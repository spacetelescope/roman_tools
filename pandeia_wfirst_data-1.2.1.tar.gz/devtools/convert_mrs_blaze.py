from csv2fits import csv2fits_thruput as csv2fits

infiles = ['../jwst/miri/blaze/ch1_blaze.csv',
           '../jwst/miri/blaze/ch2_blaze.csv',
           '../jwst/miri/blaze/ch3_blaze.csv',
           '../jwst/miri/blaze/ch4_blaze.csv']
outfiles = ['../jwst/miri/blaze/ch1_blaze.fits',
            '../jwst/miri/blaze/ch2_blaze.fits',
            '../jwst/miri/blaze/ch3_blaze.fits',
            '../jwst/miri/blaze/ch4_blaze.fits']

for infile, outfile in zip(infiles, outfiles):
    csv2fits(infile, outfile)
