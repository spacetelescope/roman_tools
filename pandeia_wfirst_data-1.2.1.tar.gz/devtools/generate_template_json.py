#!/usr/bin/env python

# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
generate_json_templates.py - a command line tool to generate JSON template files to give to INS & ReDCaT

The general flow of this data is as follows:

   1) we (SSB) deliver template files to INS (tells them what fields/sections are needed in json files)
   2) INS delivers updated data files to ReDCaT (always to include updated json config files) with current par values
   3) ReDCaT annotates them and delivers them to us in an official delivery
   4) we run redcat_ingest.py to update our files in pandeia_data with the new info
     - we look to see that any edited field also has an associated "meta" change
   5) we then use *this* script to update our template files in pandeia_data/devtools/templates

The current design is that the JSON "template" files are simply a sub-set of the full pandeia_data
JSON config files that we use in production, and the after this script is run, the template files
have the same values as those in the full files in master.

THIS WILL OVERWITE FILES IN $pandeia_refdata/devtools/templates !

"""

import glob, json, os, re, sys
from six.moves import input


# globals
DATA_DIR = os.environ['pandeia_refdata']
TELESCOPE = 'jwst'

TEMPLATES = {
    "cr.json":             TELESCOPE+'/telescope/cr_config.json',
    "shutter_config.json": 'jwst/nirspec/shutters.json',
    "telescope.json":      TELESCOPE+'/telescope/config.json',
    "miri.json":           TELESCOPE+'/miri/config.json',
    "nircam.json":         TELESCOPE+'/nircam/config.json',
    "niriss.json":         TELESCOPE+'/niriss/config.json',
    "nirspec.json":        TELESCOPE+'/nirspec/config.json'
}

#
# These are dictionary keys (currently still unique) that can be summarily
# removed when found, _anywhere_ in the json object.
#
# Leave in "range" and "readmode_config" for INS folks to edit.
#
KEYS_TO_STRIP = [

 'config_constraints',
 'disperser_config',
 'filter_config',
 'filters_unused',
 'mode_config',
 'ramp_config',
 'strategy_config',

 'dynamic_scene',
 'scene_size',
 'max_scene_size',

 'unsupported_modes',
 'readmodes_disabled_for_now_per_1589',
 'display_string'
]


# read/write
def read_json(fname):
    with open(fname) as f:
        return json.load(f)

def write_sorted_json(data, fname, meta_at_top=True):
    """
    Sort the keys so that:
    1) the output files are deterministically written, and (which helps for)
    2) humans can easily diff the output from one run to the next.
    """
    # See if we want it as sorted keys alphabetically or that PLUS "meta" sections always at top
    if meta_at_top:
        # It is requested that we alpha-sort keys but with the "meta" key always coming first.
        # If the "sort_keys" arg allowed a lambda (in both Py2 and Py3), this would be simpler,
        # but it does not.  Internet folks that need to do this seem to work around the lack
        # of a lambda by converting their data to an OrderedDict, which is slightly
        # contorted looking code.  We may need to do that someday.  For now (and for expediency)
        # we will hack this by just renaming the "meta" key before and after the dumps() call.
        rename_key(data, "meta", "-z-MUST_COME_FIRST-z-")
        # we use something starting with "-z" so that other things (e.g. -version-) can make it above meta
        the_dump_str = json.dumps(data, indent=4, separators=(',', ': '), sort_keys=True)
        the_dump_str = the_dump_str.replace("-z-MUST_COME_FIRST-z-", "meta")
    else:
        # simple/standard JSON dump
        the_dump_str = json.dumps(data, indent=4, separators=(',', ': '), sort_keys=True)

    # Now write it to the file
    with open(fname, 'w') as f:
        f.write(the_dump_str+'\n')

def strip_key(adict, akey):
    """
    Recursively strip any given key "akey" from dict "adict".  Modify the dict in place.
    """
    if isinstance(adict, dict):
        # top level
        if akey in adict:
            adict.pop(akey)
        # next level down (recurse)
        for k in adict.keys():
            strip_key(adict[k], akey)

def rename_key(adict, old_name, new_name):
    """
    Recursively change the name of any found key "old_name" from dict "adict", to "new_name".
    Modify the dict in place.
    """
    if isinstance(adict, dict):
        # top level
        if old_name in adict:
            adict[new_name] = adict[old_name]
            adict.pop(old_name)
        # next level down (recurse)
        for k in adict.keys():
            rename_key(adict[k], old_name, new_name)

timestamp_regex = re.compile(r'_\d{14}\.')

def strip_path_timestamps(adict):
    """
    Find and strip any timestamps in the "paths" sub-dict that are a part of any
    values which represent filenames.  Modify the dict in place.
    """
    if isinstance(adict, dict) and 'paths' in adict:
        for k in adict['paths']:
            val = str(adict['paths'][k])
            if timestamp_regex.search(val):
                timestamp = timestamp_regex.search(val).group(0)
                adict['paths'][k] = val.replace(timestamp, '.')



def run():

    # sanity checks
    assert os.path.exists(DATA_DIR), 'data dir non-existent: '+DATA_DIR
    assert os.path.isdir(DATA_DIR), 'data dir not a directory: '+DATA_DIR

    # warn them
    warn = "This will overwrite files in "+DATA_DIR+'/devtools/templates ...  ARE YOU SURE? (type "y"): '
    x = input(warn)
    if x not in ('Y','y','YES','yes'):
        print('Run terminated')
        return 1

    # loop over the template files to operate on (keys to TEMPLATES dict)
    for template_basename in TEMPLATES.keys():

        # input
        full_source_fname = TEMPLATES[template_basename]

        # output
        template_fname = DATA_DIR+'/devtools/templates/'+template_basename
        assert os.path.exists(full_source_fname), 'template input file non-existent: '+full_source_fname
        assert os.path.exists(template_fname), 'template output file non-existent: '+template_fname

        # load the input file, remove any dictionary KEYS_TO_STRIP, strip any timestamps
        # on filenames, then write it out
        os.remove(template_fname)
        jobj = read_json(full_source_fname)
        for key in KEYS_TO_STRIP:
            strip_key(jobj, key)
        strip_path_timestamps(jobj)
        write_sorted_json(jobj, template_fname)

    return 0


if __name__ == '__main__':
    # wrap run with sys.exit() so that non-zero status code will be sent on exception
    sys.exit(run())
