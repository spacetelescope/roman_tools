#!/usr/bin/env python

# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
redcat_ingest.py -- command-line tool for merging JWST reference data delivered via redcat
"""

import os
import sys
import argparse
import glob
import re

from pandeia.engine.io_utils import read_json, write_json
from pandeia.engine.calc_utils import strip_meta
from pandeia.engine.utils import merge_data
from pandeia.engine.custom_exceptions import DataError

# set default paths
refdir = os.path.join(os.environ['pandeia_refdata'], 'jwst')
srcdir = '/DO_NOT_USE/grp/jwst/wit/refdata/pandeia/pandeia_jwst_release_1.1dev'


class ANSIcolors:
    """
    define ANSI color codes for use in print statements
    """
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[31m'
    ENDC = '\033[0m'
    pretty_print = True


def trim_configs(d):
    """
    check that things like filters and filter_config are in sync with each other. if there are entries in filters that are
    not in filter_config, raise exception.  if there are entries in filter_config not in filters, delete them.
    """
    entries = ['filters', 'apertures', 'subarrays', 'readmodes', 'dispersers']
    for entry in entries:
        if entry not in d:
            continue
        config = entry[0:-1] + '_config'
        # make sure each item in entry has a config
        for i in d[entry]:
            if config not in d:
                msg = "%s section is missing" % config
                raise DataError(value=msg)
            if i in d[config] or ('default' in d[config] and i in d[config]['default']):
                pass # we're good
            else:
                msg = '"%s" in "%s" missing matching configuration data.' % (i, entry)
                raise DataError(value=msg)
        # if there are config entries that aren't used, trim them out (except "meta" sections)
        # (do the same thing for config sections with a 'default' sub-section
        if 'default' in d[config]:
            nuked = []
            for i in d[config]['default'].keys():
                if i not in d[entry] and i != 'meta':
                    nuked.append(i)
            for n in nuked:
                d[config]['default'].pop(n)
            # maybe add code here to do the same to trim all non-default sections as well
        else:
            nuked = []
            for i in d[config].keys():
                if i not in d[entry] and i != 'meta':
                    nuked.append(i)
            for n in nuked:
                d[config].pop(n)


def mkparser():
    """
    set up parser for command-line arguments
    """
    parser = argparse.ArgumentParser(description='command-line tool for merging JWST reference data delivered via redcat')
    parser.add_argument(
        'sections',
        metavar='<section>',
        type=str,
        nargs='*',
        help='reference data sections to merge'
    )
    parser.add_argument(
        '--src',
        metavar='<src dir>',
        type=str,
        nargs='?',
        default=srcdir,
        help='source directory for reference data'
    )
    parser.add_argument(
        '--dest',
        metavar='<dest dir>',
        type=str,
        nargs='?',
        default=refdir,
        help='destination directory'
    )
    parser.add_argument(
        '--dryrun',
        action='store_true',
        help='show what will be merged without making changes'
    )
    parser.add_argument(
        '--stripmeta',
        action='store_true',
        help='strip metadata blocks from JSON config files before merging'
    )
    parser.add_argument(
        '--nocolor',
        action='store_true',
        help='disable color-coded output'
    )
    parser.add_argument(
        '--jsononly',
        action='store_true',
        help='merge only JSON config; leave paths and other files untouched'
    )

    return parser


def cprint(string, color=ANSIcolors.OKGREEN):
    """
    color-code a string for terminal printout

    arguments
    ---------
    string: str
        string to display
    color: str
        ANSI color code to apply to string
    """
    if ANSIcolors.pretty_print:
        print(color + string + ANSIcolors.ENDC)
    else:
        print(string)


def main(args=None):
    """
    main ingestion routine
    """
    parser = mkparser()
    args = parser.parse_args(args)

    if args.nocolor:
        ANSIcolors.pretty_print = False

    # sanity check the inputs
    if len(args.sections) == 0:
        cprint("specify at least one reference data section to merge.", ANSIcolors.FAIL)
        parser.print_usage()
        parser.exit()

    for s in args.sections:
        src_path = os.path.join(args.src, s)
        dest_path = os.path.join(args.dest, s)
        if not os.path.exists(src_path):
            cprint("'%s' does not exist in source directory" % s, ANSIcolors.FAIL)
            parser.exit()
        if not os.path.exists(dest_path):
            cprint("'%s' does not exist in destination directory" % s, ANSIcolors.FAIL)
            parser.exit()

        # set up regex for redcat timestamp format
        re_ts = re.compile(r"_\d{14}")
        re_inp_main_fname = re.compile('/jwst_[mn]ir[a-z]*_configuration_2[0-9]{7}[0-9]*.json')
        re_inp_shut_fname = re.compile('/jwst_[mn]ir[a-z]*_shutters_2[0-9]{7}[0-9]*.json')

        # look for all JSON config files in the right filename format
        json_all_files = sorted(glob.glob("%s/*.json" % src_path))

        # two types of JSON cfg files: "main" (inst main config files) and "other" (e.g. shutters)
        json_main_files  = [f for f in json_all_files if '_configuration_' in os.path.basename(f)]
        json_other_files = [f for f in json_all_files if f not in json_main_files]

        # only use latest one if have multiples of same type
        if len(json_main_files) > 1:
            cprint('\nTOO MANY INSTRUMENT JSON FILES FOUND!', ANSIcolors.WARNING)
            for fff in json_main_files:
                cprint('\t'+fff, ANSIcolors.WARNING)
            cprint('\nWILL USE ONLY THE LAST ONE: '+os.path.basename(json_main_files[-1])+', IS THAT OKAY? (cntl-c to quit)\n', ANSIcolors.WARNING)
            x = raw_input()
            json_main_files = json_main_files[-1:]

        # process it/them
        for f in json_main_files + json_other_files:
            out_file = os.path.basename(f).replace("jwst_%s_" % s, "").replace("configuration", "config")
            if re_ts.search(out_file):
                timestamp = re_ts.search(out_file).group(0)
                out_file = out_file.replace(timestamp, '')
            # match the current tree - make the outfile config.json if infile is as expected
            if re_inp_main_fname.search(f) != None:
                out_file = 'config.json'
            elif re_inp_shut_fname.search(f) != None:
                out_file = 'shutters.json'
            out_path = os.path.join(dest_path, out_file)
            new_data = read_json(f)
            old_data = read_json(out_path)
            if args.dryrun:
                cprint("DRYRUN: would process %s to merge with %s..." % (f, out_path), ANSIcolors.HEADER)
            else:
                cprint("\nprocessing %s to merge with %s..." % (f, out_path), ANSIcolors.HEADER)

            # Convert new data from INS to the new structure in subarray_config as per pandeia#2814, basically
            # drop all keys in subarray_config down one level under a new 'default' key dict.
            if 'subarray_config' in new_data and 'default' not in new_data['subarray_config']:
                new_data['subarray_config']['default'] = {}
                for key_to_drop_1_level in new_data['subarray_config'].keys():
                    if key_to_drop_1_level != 'default':
                        new_data['subarray_config']['default'][key_to_drop_1_level] = new_data['subarray_config'][key_to_drop_1_level]
                        new_data['subarray_config'].pop(key_to_drop_1_level)

            # optionally strip out meta tags
            if args.stripmeta:
                strip_meta(new_data)

            # merge the old and new data
            merged_data = merge_data(old_data, new_data)

            # trim config sections in merged_data
            trim_configs(merged_data)

            # for each file in 'paths', look for matching files upstream, sort them, and pull down/point to the last in the list.
            # redcat's timestamps will make the last one the most recent. unofficial, direct deliveries should always use the
            # same filename so there should be only one.
            if args.dryrun:
                updating = "DRYRUN: would update"
            else:
                updating = "updating"

            if 'paths' in merged_data:
                if args.jsononly:
                    # if we're only pulling the JSON data, just set the 'paths' section back to the original
                    # and don't mess with any of the other files.
                    merged_data['paths'] = old_data['paths']
                else:
                    for k, v in sorted(merged_data['paths'].items()):
                        # ignore meta tags
                        if k == 'meta':
                            continue
                        cprint("Processing %s:" % k, ANSIcolors.HEADER)
                        fileroot, extension = os.path.splitext(v)
                        src_glob = "%s/%s*%s" % (src_path, fileroot, extension)
                        src_files = sorted(glob.glob(src_glob))
                        src_v = os.path.join(src_path, v)
                        dest_v = os.path.join(dest_path, v)
                        if len(src_files) == 0:
                            if os.path.exists(dest_v):
                                cprint("\t REFERENCE FILE MISSING FROM SOURCE!", ANSIcolors.WARNING)
                                cprint("\t Falling back to previous value of %s..." % v, ANSIcolors.WARNING)
                            else:
                                old_v = old_data['paths'][k]
                                old_path = os.path.join(dest_path, old_v)
                                if os.path.exists(old_path):
                                    merged_data['paths'][k] = old_v
                                    cprint("\t REFERENCE FILE MISSING FROM SOURCE!", ANSIcolors.WARNING)
                                    cprint("\t Falling back to previous value of %s..." % old_v, ANSIcolors.WARNING)
                                else:
                                    cprint("\t REFERENCE FILE %s COMPLETELY MISSING!" % v, ANSIcolors.FAIL)

                        elif src_v == src_files[-1]:
                            cprint("\t pointing to %s which is the most recent delivered version." % v)
                        else:
                            src_file = src_files.pop()
                            dest_file = src_file.replace(src_path, dest_path)
                            newest = src_file.replace("%s/" % src_path, '')
                            cprint("\t %s %s from %s to %s..." % (updating, k, v, newest))
                            if not args.dryrun:
                                os.system("cp %s %s" % (src_file, dest_file))
                                cprint("\t \t cp %s %s" % (src_file, dest_file), ANSIcolors.OKBLUE)
                                # need to be within the pandeia_data repo to git add the new file...
                                if os.environ['pandeia_refdata'] and os.environ['pandeia_refdata'] in os.getcwd():
                                    os.system("git add %s" % dest_path)
                                    cprint("\t \t git add %s" % dest_file, ANSIcolors.OKBLUE)
                            else:
                                cprint("\t \t # cp %s %s" % (src_file, dest_file), ANSIcolors.OKBLUE)
                                cprint("\t \t # git add %s" % dest_file, ANSIcolors.OKBLUE)
                            merged_data['paths'][k] = newest

            # write it out
            if not args.dryrun:
                cprint("writing JSON data to %s..." % out_path, ANSIcolors.HEADER)
                write_json(merged_data, out_path, sort_keys=True)


if __name__ == '__main__':
    # wrap main() with sys.exit() so that non-zero status code will be generated when exception raised
    sys.exit(main())
