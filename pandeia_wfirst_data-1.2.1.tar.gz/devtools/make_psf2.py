#!/usr/bin/env python

import webbpsf as wp
import numpy as np
import os
import multiprocessing as mp
from sys import argv
import copy
import json
import sys

import astropy.io.fits as pf

COMPRESSION = False
MAKE_PSF_VERSION = 2.1
#COMPRESSION = 65536

"""
Until we upgrade to Python 3, there is no reliable way to calculate the pupil throughput 
and THEN begin iterating. To avoid each subprocess generating PSFs with a different 
pupil_throughput keyword, you should NOT run this on more than 1 core.
"""

class PSFInstrument():
    """
    Parent class for all instruments

    Parameters
    ----------

    Attributes
    ----------
        data_dir: string
            The location of the Pandeia Reference Data
        config: dict
            The instrument configuration file, as a dictionary
        instrument: WebbPSF Instrument
            A JWSTInstrument class from WebbPSF

        aperture: string
            The aperture for which PSFs are being requested.
        aperture_name: string
            The aperture name to use in the fits file and its filename (different only for NIRSpec)
        coronagraph_source_offsets: list
            r, theta pairs of source offset positions for use with coronagraphic modes
        fov_pixels: int
            Size of one dimension of the (square) FOVs in pixels, before oversampling.
        include_si_wfe: book
            Indicates whether to load the measured wavefront errors (as opposed
            to the predicted ones)
        minwave: float
            The minimum wavelength defined in WebbPSF, for which PSFs can be generated.
            Overridden by NIRISS and NIRCAM
        maxwave: float
            The maximum wavelength defined in WebbPSF for which PSFs can be generated.
            Overridden by NIRISS and NIRCAM
        n_cores: int
            The number of threads to use in parallel to generate PSFs.
        nstep: int
            The step skip size to use when cutting down the master wavelength grid to a
            reasonable number of points.
        oversample: int
            The number of points to oversample the PSF. Overridden by NIRSpec
        trim_fov_pixels: int
            Trim the PSF to just this many pixels, centered. Used only by NIRCAM

    Methods
    -------
    create_psfs:
        Sets up lists of all the PSFs that need to be made for that instrument/aperture
        combination. Overridden by NIRCAM for maskswb and masklwb because the bar psfs
        require a lot of special treatment.
    _master_wave:
        Creates the wavelength grid that all instruments and apertures are snapped into
    _get_wave_range:
        Given an aperture and filter(s), get the wavelength range specified in the config
        and then find what grid values to snap to
    _get_wave_elements:
        Given an aperture, find all the filters and dispersers that are meant to be used
        with it
    _split_multi:
        Divide up the list of PSFs to generate between some number of threads
    genpsf:
        Accepts one PSF dictionary, outputs one generated PSF in a .fits file
    _psf_runner:
        Used by _split_multi to run an entire (sub-)list of PSFs through genpsf


    """
    def __init__(self):
        self.data_dir = os.environ['pandeia_refdata']
        config_file = open('{0:}/{1:}/{2:}/config.json'.format(self.data_dir,self.telescope,self.insname))
        self.config = json.load(config_file)

        psf_file = open('{0:}/{1:}/{2:}/psf.json'.format(self.data_dir,self.telescope,self.insname))
        self.psfconfig = json.load(psf_file)

        # apply PSF configuration from the file
        self._load_config()

        self._master_wave()

    def _load_config(self):
        """
        Load PSF configuration from a file.
        
        The general structure is a json file, with three major categories:
        
        "instrument" contains global instrument properties to be loaded directly into the 
            WebbPSF instrument.
        "general" contains global instrument properties that should live in the Class object.
        "aperture" contains aperture-specific properties, and is itself divided into 
            instrument and general sub-categories.
        There are additional attributes that do not fall under those umbrella headings.
        """

        # load and set global instrument configuration
        for item in self.psfconfig['instrument']:
            setattr(self.instrument,item,self.psfconfig['instrument'][item])
        for item in self.psfconfig['general']:
            setattr(self,item,self.psfconfig['general'][item])

        # load aperture-specific configuration
        for item in self.psfconfig['apertures'][self.aperture]['instrument']:
            setattr(self.instrument,item,self.psfconfig['apertures'][self.aperture]['instrument'][item])
        for item in self.psfconfig['apertures'][self.aperture]['general']:
            setattr(self,item,self.psfconfig['apertures'][self.aperture]['general'][item])

        # detector scattering is special
        if 'detector_scat' in self.psfconfig:
            for item in self.psfconfig['detector_scat']:
                setattr(self,item,self.psfconfig['detector_scat'][item])
            self.detector_scat = True
        
        # detector scattering is also special
        self.instrument.pixelscale = self.config['aperture_config'][self.aperture]['pix']

        # minwave and maxwave are also special
        if 'minwave' in self.psfconfig['apertures'][self.aperture]:
            if self.psfconfig['apertures'][self.aperture]['minwave'] == 'short_min':
                self.minwave = self.instrument.SHORT_WAVELENGTH_MIN*1e6
            elif self.psfconfig['apertures'][self.aperture]['minwave'] == 'long_min':
                self.minwave = self.instrument.LONG_WAVELENGTH_MIN*1e6
            else:
                raise ValueError('Unable to read wavelengths')
        if 'maxwave' in self.psfconfig['apertures'][self.aperture]:
            if self.psfconfig['apertures'][self.aperture]['maxwave'] == 'short_max':
                self.minwave = self.instrument.SHORT_WAVELENGTH_MAX*1e6
            elif self.psfconfig['apertures'][self.aperture]['maxwave'] == 'long_max':
                self.minwave = self.instrument.LONG_WAVELENGTH_MAX*1e6
            else:
                raise ValueError('Unable to read wavelengths')

    def _detector_scat(self,wave):
        '''
        The loss due to detector scattering in the
        MIRI imaging detector. A function of wavelength, returns a float between 0 and 1
        The detector may scatter light to large distances, leading to an effective
        loss of throughput in sources (the background is not affected). This is
        an issue for MIRI, but not currently for the other instruments
        (see Glasse et al. 2015). This function will decrease the PSF throughput by
        a factor.
        '''
        f_det = 1. - self.a_det * np.exp(-(self.tau1 + self.tau2) * (wave / self.wave_0)**2.)
        return f_det

    def create_psfs(self,n_cores):
        """
        Create PSFs by setting up all the names, wavelengths, and offsets, then passing them
        to the system that splits them off into parallel generation.

        Parameters
        ----------
        n_cores: int
            The number of parallel generation instances to run
        """

        waveelements = self._get_wave_elements()
        wavelengths = self._get_wave_range_fixedn(waveelements)
        try:
            self.aperture_name # the only aperture that should already have this is nirspec
        except AttributeError:
            self.aperture_name = self.aperture

        psfs = []
        if not hasattr(self,'coronagraph_source_offsets'):
            self.coronagraph_source_offsets = [(0.0,0.0)]
            
        for r,theta in self.coronagraph_source_offsets:

            psfs = []
            for wave in wavelengths:
                if r > 0.001:
                    # Basename + aperture + wavelength + (if non-trivial) distance from on-axis and
                    # angle from vertical as defined in WebbPSF
                    longname = '{0:}_{1:}_{2:.4f}_{3:.3f}_{4:.0f}.fits'.format(self.insname,self.aperture_name,wave,r,theta)
                else:
                    longname = '{0:}_{1:}_{2:.4f}.fits'.format(self.insname,self.aperture_name,wave)
                psf = {'psf':self.instrument, 'wave':wave*1e-6, 'filename':longname, 'optimal_offset_r': None, 'optimal_offset_theta': None, 'source_offset_r': r, 'source_offset_theta': theta}
                psfs.append(psf)
            self._split_multi(n_cores,psfs)

    def _master_wave(self):
        """
        Calculate a wavelength grid for all PSFs to be sampled from.

        Keywords
        --------
        wmin: float
            the minimum wavelength for the master grid
        wmax: float
            the maximum wavelength for the master grid
        n: int
            the number of steps in the master grid

        Returns
        -------
        wvals: ndarray
            the master log-normal wavelength grid
        """

        n = 2000
        wmin = 0.3
        wmax = 34.0
        a = (n -1)/(np.log(wmax) - np.log(wmin))
        b = n - (a * np.log(wmax))
        
        arr = np.arange(n)+1
        self.masterwave = np.exp((arr - b)/a)
    
    def _get_wave_range_fixedn(self,waveelements):
        if self.aperture in ['maskswb', 'masklwb']:
            wrange = self.config['range'][aperture][waveelements[0]]
            self.genmin = wrange['wmin']
            self.genmax = wrange['wmax']
            self.gennum = int(10.0 * (self.genmax - self.genmin))
        nw = float(self.gennum)
        waves = (np.arange(nw) / (nw - 1)) ** 2. * (self.genmax - self.genmin) + self.genmin
    
        return waves
    
    def _get_wave_range_fixedgrid(self, waveelements):
        """
        Identify the required wavelengths for an actual calculation
    
        Keywords
        --------
        config: dict
            json dictionary of instrument configuration
        aperture: str
            the requested aperture to get range
        nstep: int
            the density of sampling into the master wavelength grid
    
        Returns
        -------
        waves: ndarray
            the wavelength points needed to span the wavelength range at the specified scaling
        """
    
        minwave = 9999
        maxwave = 0

        if len(waveelements) != 0:
            for waveelement in waveelements:
                try:
                    if self.config['range'][self.aperture][waveelement]['wmax'] > maxwave:
                        maxwave = self.config['range'][self.aperture][waveelement]['wmax']
                    if self.config['range'][self.aperture][waveelement]['wmin'] < minwave:
                        minwave = self.config['range'][self.aperture][waveelement]['wmin']
                except KeyError:
                    print('   Wavelengths for {0:}/{1:} are missing!'.format(self.aperture, waveelement))
        else:
            try:
                if self.config['range'][self.aperture]['wmax'] > maxwave:
                    maxwave = self.config['range'][self.aperture]['wmax']
                if self.config['range'][self.aperture]['wmin'] < minwave:
                    minwave = self.config['range'][self.aperture]['wmin']
            except KeyError:
                print('   Wavelengths for {0:} are missing!'.format(self.aperture))

        if minwave < self.minwave:
            print("Requested wavelength ({0:.4f}) below minimum defined ({1:.4f}) for {2:}".format(minwave,self.minwave,self.insname))
        if maxwave > self.maxwave:
            print("Requested wavelength ({0:.4f}) above maximum defined ({1:.4f}) for {2:}".format(maxwave,self.maxwave,self.insname))

        # cut down to just the step size steps
        mwave = [self.masterwave[x] for x in range(len(self.masterwave)) if x%self.nstep == 0]
        # grab the last wavelength BEFORE they become greater than minwave
        mindex = [k for k in range(len(mwave)) if mwave[k] <= minwave][-1]
        # grab the first wavelength AFTER they become greater than maxwave
        maxdex = [k for k in range(len(mwave)) if mwave[k] >= maxwave][1]
        
        waves = np.asarray(mwave[mindex:maxdex])

        # protect against wavelengths not supported by WebbPSF
        badmin = [k for k in range(len(waves)) if waves[k] < self.minwave]
        badmax = [k for k in range(len(waves)) if waves[k] > self.maxwave]
        waves[badmin] = self.minwave
        waves[badmax] = self.maxwave
        # and now protect against having MULTIPLES of the above.
        waves = np.unique(waves)
    
        return waves
    
    def _get_wave_elements(self):
        '''
        Given a json configuration dictionary and an aperture, find the filters
        and dispersers supported for that aperture.
    
        Returns
        -------
        elements: list
            a list of all filters and dispersers defined for that wavelength
        '''
        elements = []
        mode_elements_list = []
        for mode in self.config['mode_config']:
            if 'apertures' not in self.config['mode_config'][mode]: # if it's not defined, it's all apertures.
                self.config['mode_config'][mode]['apertures'] = self.aperture
            if self.aperture in self.config['mode_config'][mode]['apertures']:
                mode_elements = []
                try:
                    mode_elements.extend(self.config['mode_config'][mode]['filters'])
                except KeyError:
                    pass
                    #print('   No filter definition block for {0:}'.format(mode))
                try:
                    mode_elements.extend(self.config['mode_config'][mode]['dispersers'])
                except KeyError:
                    pass
                    #print('   No disperser definition block for {0:}'.format(mode))
            
    
                for element in ['filters','dispersers']:
                    try:
                        if self.aperture in self.config['config_constraints']['apertures']:
                            if element in self.config['config_constraints']['apertures'][self.aperture]:
                                if mode in self.config['config_constraints']['apertures'][self.aperture][element]:
                                    out_elements = self.config['config_constraints']['apertures'][self.aperture][element][mode]
                                elif "default" in self.config['config_constraints']['apertures'][self.aperture][element]:
                                    out_elements = self.config['config_constraints']['apertures'][self.aperture][element]['default']
                                    if out_elements is None: # nirspec defines one of these as "None" meaning all filters.
                                        out_elements = mode_elements
                                else:
                                    out_elements = self.config['config_constraints']['apertures'][self.aperture][element]
                            else:
                                out_elements = []
                        else:
                            out_elements = []
                    except KeyError:
                        out_elements = []
                    elements.extend(out_elements)
                mode_elements_list.extend(mode_elements)

        if len(elements) == 0:
            elements = list(set(mode_elements_list))
        else:
            elements = list(set(elements))

        # miri has a 'None' filter
        if None in elements:
            elements.remove(None)
            
        # niriss soss has one "disperser" for each order
        if hasattr(self,'special_elements'):
            elements.extend(self.special_elements)

        # We don't need a separate PSF library for the neutral density spots. 
        elements = [element for element in elements if '_nd' not in element]

        return elements
        
    def _get_pupil_throughput(self,inputs):
        # First calculate a PSF in the first wavelength bin for the maximal FOV to calculated the pupil loss.
        # Note that the pupil loss is constant as a function of wavelength, so we only need to do this once per
        # psf_suite
        # The maximum FOV size is 512 lambda/D (according to M. Perrin, priv. comm.)
        fov_arcsec = 512.0 * inputs['wave']/6.5 * 206265.0
        if inputs['optimal_offset_r'] is not None:
            inputs['psf'].options['bar_offset'] = 0.0
        psf_full_fov = inputs['psf'].calcPSF(oversample=self.oversample, 
                                  fov_arcsec=fov_arcsec, 
                                  monochromatic=inputs['wave'])

        self.pupil_throughput = np.sum(psf_full_fov[0].data)
        
    def _split_multi(self,n_cores,psfs):
        """
        Split up the calculations into n_cores parallel threads

        Keywords
        --------
        n_cores: int
            The number of threads to split off into
        psfs: list
            A list of all the dictionaries setting up PSFs
        """
        self._get_pupil_throughput(psfs[0])
        
        ctx = mp.get_context('forkserver')

        # now we have a list of all the PSFs we want to generate.
        processes = []
        for x in range(n_cores):
            to_generate = [psfs[k] for k in range(len(psfs)) if k%n_cores == x]
            processes.append(ctx.Process(target=self._psf_runner, args=([to_generate])))
            processes[-1].start()
        processes[-1].join() # block further execution until the last process finishes.

    def gen_psf(self,inputs):
        """
        Method to calculate a suite (range of wavelengths) of monochromatic PSFs
        with a format appropriate for use with Pandeia.

        Keywords
        --------
        inputs: dict
            A dictionary of all (changing) information necessary to generate the PSF.
        """

        wave = inputs['wave']
        instrument = inputs['psf']
        source_offset_r = inputs['source_offset_r']
        source_offset_theta = inputs['source_offset_theta']
        optimal_offset_r = inputs['optimal_offset_r']
        optimal_offset_theta = inputs['optimal_offset_theta']
        if optimal_offset_r is not None:
            instrument.options['bar_offset'] = 0.0
        filename = inputs['filename'].lower()
        
        if os.path.isfile(filename):
            print("{0:} already exists. skipping...".format(filename))
            return
        else:
            print("Creating {0:}...".format(filename))

        # If off-axis, return center to origin
        if source_offset_r > 0.0001:
            source_offset_theta_rad = np.radians(source_offset_theta)
            # Round to nearest integer subsampled pixel to avoid interpolations.
            # in webbpsf, when theta is 0, r is aligned with the +Y axis and theta increases CCW from there
            dx = source_offset_r * np.sin(source_offset_theta_rad)
            dy = source_offset_r * np.cos(source_offset_theta_rad)
            dx_pix = dx / instrument.pixelscale
            dy_pix = dy / instrument.pixelscale
            dx_pix_round = int(np.rint(dx_pix))
            dy_pix_round = int(np.rint(dy_pix))
            source_offset_r_pix = np.sqrt(dx_pix_round**2 + dy_pix_round**2)
            if dx_pix_round > 0 and np.abs(source_offset_theta) != 90.0:
                source_offset_theta = np.degrees(np.arctan(np.abs(dy_pix_round / dx_pix_round)))

            instrument.options['source_offset_r'] = source_offset_r_pix * instrument.pixelscale
            instrument.options['source_offset_theta'] = source_offset_theta
            dmax = np.max([np.abs(dx_pix_round), np.abs(dy_pix_round)])
            #instrument.options['fov_pixels']=self.fov_pixels
            instrument.calcPSF(oversample=self.oversample, fov_pixels=self.fov_pixels + 2 * dmax, monochromatic=wave,
                               outfile=filename, overwrite = True)

            psf = pf.open(filename, mode='update')

            psf[0].data = np.roll(psf[0].data, dx_pix_round * self.oversample, axis=1)
            psf[0].data = np.roll(psf[0].data, -dy_pix_round * self.oversample, axis=0)
            psf[0].data = psf[0].data[dmax * self.oversample:(self.fov_pixels + dmax) * self.oversample,
                                      dmax * self.oversample:(self.fov_pixels + dmax) * self.oversample]
            if hasattr(self,'trim_fov_pixels') and self.fov_pixels is not None:
                trim_amount = int(self.oversample * (self.fov_pixels - self.trim_fov_pixels) / 2)
                psf[0].data = psf[0].data[trim_amount:-trim_amount, trim_amount:-trim_amount]
            psf.close()
        else:
            instrument.options['source_offset_r'] = 0.
            instrument.options['source_offset_theta'] = 0.
            instrument.calcPSF(oversample=self.oversample, fov_pixels=self.fov_pixels, monochromatic=wave,
                               outfile=filename,overwrite = True)

        # Add mode keyword to header
        hdulist = pf.open(filename)
        prihdr = hdulist[0].header
        prihdr['MAKE_PSF'] = (MAKE_PSF_VERSION, 'Version of make_psf used to generate these files')
        prihdr['PUP_THRU'] = (self.pupil_throughput, 'The relative throughput of the pupil')
        prihdr['APERTURE'] = (self.aperture_name, 'The observing aperture within the instrument FOV')
        prihdr['OFFSET_R'] = (source_offset_r, 'The radial distance in arcsec to the axis')
        prihdr['OFFSET_T'] = (source_offset_theta, 'The source angle in degrees')
        if optimal_offset_r is not None and optimal_offset_theta is not None:
            prihdr['OPTOFF_R'] = (optimal_offset_r, 'radial distance to optimal FOV position')
            prihdr['OPTOFF_T'] = (optimal_offset_theta, 'source angle in degrees relative to optimal FOV position')

        if hasattr(self,'rot90'):
            hdulist[0].data = np.rot90(hdulist[0].data)

        if hasattr(self,'detector_scat'):
            hdulist[0].data *= self._detector_scat(wave*1e6)

        if COMPRESSION:
            comphdu = pf.CompImageHDU(hdulist[0].data,prihdr,compression_type='GZIP_1',quantize_level=COMPRESSION)
            hdulist.close()
            comphdu.writeto(filename, overwrite=True)
            comphdulist.close()
        else:
            hdulist.writeto(filename, overwrite=True)
            hdulist.close()

    def _psf_runner(self,psfs):
        for psf in psfs:
            self.gen_psf(psf)



class miri(PSFInstrument):

    def __init__(self, aperture):
        """
        Set up a MIRI instrument and aperture, and MIRI-specific features

        Methods
        -------
        _detector_scat
            MIRI is uniquely prone to scattering within the detector; this models that 
            blurring effect as a throughput loss as a function of wavelength.
        """

        self.instrument = wp.MIRI()
        self.insname = 'miri'
        self.telescope = 'jwst'
        self.aperture = aperture
        
        # load configuration
        PSFInstrument.__init__(self)



class niriss(PSFInstrument):

    def __init__(self, aperture):
        """
        Set up a NIRISS instrument and aperture, and NIRISS-specific features
        """
        self.instrument = wp.NIRISS()
        self.insname = 'niriss'
        self.telescope = 'jwst'
        self.aperture = aperture
        
        # load configuration
        PSFInstrument.__init__(self)



class nirspec(PSFInstrument):

    def __init__(self, aperture):
        """
        Set up a NIRSpec instrument and aperture, and NIRSpec-specific features
        """
        self.instrument = wp.NIRSpec()
        self.insname = 'nirspec'
        self.telescope = 'jwst'
        self.aperture = aperture        

        # load configuration
        PSFInstrument.__init__(self)



class nircam(PSFInstrument):

    def __init__(self, aperture):
        """
        Set up a NIRCam instrument and aperture, and NIRCam-specific features

        Methods
        -------
        create_psfs:
            Override the default version so that bar PSFs can be handled differently
        create_bar_psfs:
            Special routine for handling the maskswb and masklwb bar occulters
        _swb_width:
            Returns the width of the short wavelength bar, as a function of filter
        _lwb_width:
            Returns the width of the long wavelength bar, as a function of filter
        """
        self.instrument = wp.NIRCam()
        self.insname = 'nircam'
        self.telescope = 'jwst'
        self.aperture = aperture
        
        # load configuration
        PSFInstrument.__init__(self)

    def create_psfs(self,n_cores):
        if self.aperture in ['masklwb', 'maskswb']:
            psfs = self.create_bar_psfs()
        else:
            psfs = PSFInstrument.create_psfs(self,n_cores)
            return

    # this function provides the bar width as a function of X (i.e. bar_offset in arcsec).
    # the source offsets will be in units of bar width for consistency.
    def _bar_width(self,x):
        width = self.barwidth_0 + self.barwidth_1 * x
        return width

    def create_bar_psfs(self):
        # for the occulting bars, we need to move the source along the bar as a function of wavelength to
        # optimize the performance of the occulter. get the optimal offset for each filter from the instrument config file.
        # the offsets are in arcseconds and increase with bar thickness (i.e. negative offsets are at the narrower
        # end; positive at wider end). also get which filters go with each bar from the config file.
        bar_offsets = self.config['bar_offsets']
        waveelements = self._get_wave_elements()
        # We will set bar offsets, not rely on WebbPSF's default settings
        self.instrument.options['bar_offset'] = 0.0

        # the bars are rotated -90 degrees w.r.t. the webbpsf coordinate system
        bar_angle = 90.0

        # loop through the filters and make a set of PSFs for each one centered at the optimal bar position
        for element in waveelements:
            # get the optimal bar position for this filter
            x = bar_offsets[element]
            width = self._bar_width(x)
            
            self.aperture_name = "{0:}{1:}".format(self.aperture,element)
            wavelengths = self._get_wave_range_fixedn([element])
            
            self.coronagraph_source_offsets = [[np.abs(x),np.sign(x)*bar_angle,0.0,0.0]]
            
            # now loop through the offsets and angles for positions around the optimal position
            for offset in self.src_offsets:
                for angle in self.angles:
                    offset_arcsec = width * offset  # offsets in units of bar widths
                    rad = np.radians(angle)
                    # dx and dy are arcsec from the optical position for filt.
                    # in pandeia, 0 degrees is along +X axis rather than +Y like webbpsf.
                    # also X increases to right in pandeia, to left in webbpsf...
                    dx = offset_arcsec * np.cos(rad)
                    dy = offset_arcsec * np.sin(rad)
                    r = np.sqrt(dx**2 + dy**2)
                    # now use the bar_offset to get the r and theta values referenced to the bar center that
                    # we need to pass to webbpsf
                    x_img = x - dx  # this is because of webbpsf X flip...
                    r_img = np.sqrt(x_img**2 + dy**2)
                    theta_img = np.degrees(np.arctan2(dy, x_img)) - np.sign(x) * bar_angle
                    # the angle used in filenaming needs to be positive...
                    if angle < 0.0:
                        angle += 360.0
                    self.coronagraph_source_offsets.append([r_img,theta_img,r,angle])

            for r_img,theta_img,r,angle in self.coronagraph_source_offsets:

                psfs = []
                for wave in wavelengths:
                    longname = '{0:}_{1:}_{2:.4f}_{3:.3f}_{4:.0f}.fits'.format(self.insname,self.aperture_name,wave,r,angle)
                    psf = {'psf':self.instrument, 'wave':wave*1e-6, 'filename':longname, 'optimal_offset_r': r, 'optimal_offset_theta': angle, 'source_offset_r': r_img, 'source_offset_theta': theta_img}
                    psfs.append(psf)
                self._split_multi(n_cores,psfs)



class wfirstimager(PSFInstrument):

    def __init__(self, aperture):
        """
        Set up a WFIRST imager instrument and aperture, and WFIRST imager-specific features
        """
        self.instrument = wp.wfirst.WFI()
        self.insname = 'wfirstimager'
        self.telescope = 'wfirst'
        self.aperture = aperture

        # load configuration
        PSFInstrument.__init__(self)



class wfirstifu(PSFInstrument):

    def __init__(self, aperture):
        """
        Set up a WFIRST IFU instrument and aperture, and WFIRST ifu-specific features
        """
        self.instrument = wp.wfirst.WFI()
        self.insname = 'wfirstifu'
        self.telescope = 'wfirst'
        self.aperture = aperture

        # load configuration
        PSFInstrument.__init__(self)



if __name__ == "__main__":
    data_dir = os.environ['pandeia_refdata']

    if len(argv) > 1:
        n_cores = np.int(argv[1])
    else:
        print("Usage: python make_psf.py cores instrument,aperture,... ...")
    if len(argv) > 2:
        generate = argv[2:]
    else:
        config_file = open('{0:}/{1:}/{2:}/config.json'.format(data_dir,'jwst','telescope'))
        config = json.load(config_file)
        generate = config['instruments']       

    for ins in generate:
        instrument = ins.split(',')[0]
        apertures = ins.split(',')[1:]
        if len(apertures) == 0:
            config_file = open('{0:}/{1:}/{2:}/config.json'.format(data_dir,'jwst',instrument))
            config = json.load(config_file)
            apertures = config['apertures']
            if ins == 'nirspec': # NIRSPEC has a mirror that's not mentioned in the config.json file
                apertures.append('mirror')
        if COMPRESSION:
            print("Using fpack compression, quantization level {0:}".format(COMPRESSION))
        print(instrument,apertures)
        for aperture in apertures:
            if instrument == 'miri':
                generator = miri(aperture)
            if instrument == 'nircam':
                generator = nircam(aperture)
            if instrument == 'niriss':
                generator = niriss(aperture)
            if instrument == 'nirspec':
                if aperture == 'full': # NIRSPEC has a "full" aperture that's never defined or used.
                    continue
                else: 
                    generator = nirspec(aperture)
            if instrument == 'wfirstimager':
                generator = wfirstimager(aperture)
            if instrument == 'wfirstifu':
                generator = wfirstifu(aperture)
            generator.create_psfs(n_cores)
