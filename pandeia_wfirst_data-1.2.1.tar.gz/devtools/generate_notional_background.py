#!/usr/bin/env python

# Licensed under a 3-clause BSD style license - see LICENSE.rst

import sys
import os
import glob

import astropy.io.fits as fits
from astropy.table import Table

for txtfile in glob.glob("*.txt"):
    fitsfile = txtfile.replace('txt', 'fits')
    t = Table.read(txtfile, format='ascii')
    wave = t['col1'].data
    sb = t['col2'].data
    w_col = fits.Column(name='WAVELENGTH', format='1D', unit='UM', disp="F10.1", array=wave)
    b_col = fits.Column(name='SB', format='1D', unit='MJy/sr', disp="G12.5", array=sb)

    cols = fits.ColDefs([w_col, b_col])

    tb_hdu = fits.new_table(cols)
    hdr = fits.Header()

    pri_hdu = fits.PrimaryHDU(header=hdr)
    out_hdu = fits.HDUList([pri_hdu, tb_hdu])

    out_hdu.writeto(fitsfile, clobber=True)
