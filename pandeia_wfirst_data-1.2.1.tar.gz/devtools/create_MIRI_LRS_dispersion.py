'''
Script to create Pandeia dispersion reference files for MIRI from input .csv dispersion and resolving power curves.
'''
import os
import numpy as np
import scipy.interpolate as ip
from astropy.io import fits
import astropy.io.ascii as at

outfile = 'p750l_disp.fits'
disp_file = 'p750l_disp.txt'
r_file = 'p750l_r.txt'
path = '../jwst/miri/dispersion'

disp_data = at.read(os.path.join(path,disp_file))
r_data = at.read(os.path.join(path,r_file))

wave = disp_data['col1']
# reversing so that increasing wavelength is along increasing pixel column to follow Pandeia convention.
pixel = 400-disp_data['col2']#[::-1] 

max_pixel = int(np.max(pixel))
min_pixel = int(np.min(pixel))+1
pixels = np.arange(min_pixel,max_pixel)
wave_pix = ip.interp1d(pixel,wave)
wave_int = wave_pix(pixels)

rpower = ip.interp1d(r_data['col1'],r_data['col2'])
rpower_int = rpower(wave_int)

dlds_int = np.gradient(wave_int)
dlds_coeffs = np.polyfit(wave_int,dlds_int,7)
dlds_smooth = np.poly1d(dlds_coeffs)
dlds_int = dlds_smooth(wave_int)

ssubs = np.argsort(wave_int)
wave_int = wave_int[ssubs]
dlds_int = dlds_int[ssubs]

lrange = (np.min(wave), np.max(wave))

c1 = fits.Column(name='PIXELS', unit='PIXELS', format='1D', disp='I4', array=pixels)
c2 = fits.Column(name='WAVELENGTH', unit='UM', format='1D', disp='F10.1', array=wave_int)
c3 = fits.Column(name='DLDS', unit='UMPERPIXEL', format='1D', disp='G12.5', array=dlds_int)
c4 = fits.Column(name='R', unit='NONE', format='1D', disp='G12.5', array=rpower_int)

coldefs = fits.ColDefs([c1, c2, c3, c4])

hdu = fits.PrimaryHDU()
tbhdu = fits.BinTableHDU.from_columns(coldefs)
thdulist = fits.HDUList([hdu, tbhdu])

thdulist.writeto(os.path.join(path,outfile), clobber=True)
