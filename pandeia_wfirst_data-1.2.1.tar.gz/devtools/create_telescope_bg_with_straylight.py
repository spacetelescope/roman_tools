import numpy as np
import matplotlib.pylab as plt
import astropy.io.fits as fits
import astropy.io.ascii as ascii
from astropy.analytic_functions import blackbody_nu
from astropy import units as u

'''
This script calculated the telescope thermal AND scattered light background. The approach is that of Glasse et al. 2015 for long wavelengths, and it uses the table from the M. Rieke NIRCam sensitivity spreadsheet dated 06/15/2016. We note that the Glasse et al. estimate is significantly lower than that of Lightsey & Wei 2012 for the scattered light component. However, adding an extrapolation of the Rieke value brings the Glasse et al. and the Lightsey & Wei numbers closer to each other. This estimate should be replaced by input from GSFC. 
'''

temps = [51.7,62.0,71.0,133.8]
emis = [1.48e-2,1.72e-3,9.7e-5,3.35e-7]

wave = np.logspace(np.log10(0.5),np.log10(30),100)
sb_long = blackbody_nu(wave*u.micron,1.) * 0.
for temp,emi in zip(temps,emis):
    I_comp = blackbody_nu(wave*u.micron,temp) * emi
    sb_long += I_comp

sb_long = sb_long.to(u.MJy/u.sr)

scat_table = ascii.read('../../pandeia_verification/verification_tools/inputs/nircam_verification_background_mrieke_061416.tab')
wave_mu = scat_table['col1'].data
scat_MJy = scat_table['col3'].data

sb_short = np.interp(wave,wave_mu, scat_MJy)

sb_tot = sb_short+sb_long.value

w_col = fits.Column(name='WAVELENGTH', format='1D', unit='UM', disp="F10.1", array=wave)
b_col = fits.Column(name='SB', format='1D', unit='MJy/sr', disp="G12.5", array=sb_tot)

cols = fits.ColDefs([w_col, b_col])

tb_hdu = fits.new_table(cols)
hdr = fits.Header()

pri_hdu = fits.PrimaryHDU(header=hdr)
out_hdu = fits.HDUList([pri_hdu, tb_hdu])

out_hdu.writeto('ote_background.fits', clobber=True)

