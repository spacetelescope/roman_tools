#!/usr/bin/env python

from webbpsf import wfirst
import numpy as np
import os
import pyfits as pf

def psf_suite(nw=30, wmin=0.5, wmax=6., instrument=None,
              outname='PSF', fov_arcsec=None, fov_pixels=None, oversample=3,
              aperture='any', rot90=False, source_offset_r=0., source_offset_theta=0.):
    """
    Method to calculate a suite (range of wavelengths) of monochromatic PSFs
    with a format appropriate for use with Pandeia.

    Keywords
    --------
    nw: integer
        Number of wavelength planes
    wmin: float
        Minimum wavelength (in microns)
    wmax: float
        Maximum wavelength (in microns)
    instrument: WebbPSF instrument class
        The instrument/mode to use. Has to be instantiated prior to the call
        using WebbPSF
    outname: string
        Base name for the output PSF files
    fov_arcsec: float
        Size of the field of view in arcseconds. Cannot be specified at the
        same time as fov_pixels.
    fov_pixels: integer
        Size of the field of view in detector (not oversampled) pixels. Cannot
        be specified at the same time as fov_arcsec
    aperture: string
        name of the aperture relevant for the PSF. This name is used by
        Pandeia to match the PSFs in a library to a given instrument/mode.
    rot90: bool
        rotate the PSF by 90 degrees. The Pandeia convention is to disperse
        spectra in the horizontal (x) direction. This may not match the WebbPSF
        assumption. Eventually, this may be superseded by a more stringent
        treatment of detector/dispersion/sky axes.


    """

    nw = float(nw)
    waves = (np.arange(nw) / (nw - 1)) ** 2. * (wmax - wmin) + wmin
    waves_m = waves * 1e-6

    for wave in waves_m:
        if source_offset_r > 0.:
            # Basename + aperture + wavelength + (if non-trivial) distance from on-axis and
            # angle from vertical as defined in WebbPSF
            longname = outname + '_' + aperture + '_{0:.4f}'.format(wave * 1e6) + \
                '_{0:.3f}'.format(source_offset_r) + '_{0:.0f}'.format(source_offset_theta) + '.fits'
        else:
            longname = outname + '_' + aperture + '_{0:.4f}'.format(wave * 1e6) + '.fits'

        longname = longname.lower()
        if os.path.isfile(longname):
            os.remove(longname)
        instrument.options['output_mode'] = 'oversampled'
        instrument.options['parity'] = 'odd'

        """
        The oversample parameter is hardcoded to 3. This is a decision based on
        three considerations 1) accuracy - many JWST modes are natively
        undersampled. Therefore, oversampling=1 is rarely sufficient. 2) The
        oversampling factor *must* currently be odd, otherwise the internal
        Pandeia PSF convolution will result in half-pixel spatial shifts. 3)
        Performance - the calculation time for a NxN image scales as
        O(N^2 log2 (N)), so oversampling factors larger than 3 rapidly lead
        to excessive calculation times.
        """

        # If off-axis, return center to origin
        if source_offset_r > 0:
            source_offset_theta_rad = np.radians(source_offset_theta)
            # Round to nearest integer subsampled pixel to avoid interpolations
            dx = source_offset_r * np.cos(source_offset_theta_rad)
            dy = source_offset_r * np.sin(source_offset_theta_rad)
            dx_pix = dx / instrument.pixelscale
            dy_pix = dy / instrument.pixelscale
            dx_pix_round = int(np.rint(dx_pix))
            dy_pix_round = int(np.rint(dy_pix))
            source_offset_r_pix = np.sqrt(dx_pix_round**2 + dy_pix_round**2)
            if dx_pix_round > 0:
                source_offset_theta = np.degrees(np.arctan(np.abs(dy_pix_round / dx_pix_round)))
            else:
                source_offset_theta = 0.

            instrument.options['source_offset_r'] = source_offset_r_pix * instrument.pixelscale
            instrument.options['source_offset_theta'] = source_offset_theta

            dmax = np.max([dx_pix_round, dy_pix_round])
            instrument.calcPSF(oversample=oversample, fov_pixels=fov_pixels + 2 * dmax, monochromatic=wave,
                               outfile=longname, clobber='true')
            psf = pf.open(longname, mode='update')

            psf[0].data = np.roll(psf[0].data, -dx_pix_round * oversample, axis=0)
            psf[0].data = np.roll(psf[0].data, dy_pix_round * oversample, axis=1)
            psf[0].data = psf[0].data[dmax * oversample:(fov_pixels + dmax) * oversample,
                                      dmax * oversample:(fov_pixels + dmax) * oversample]
            psf.close()
        else:
            instrument.options['source_offset_r'] = 0.
            instrument.options['source_offset_theta'] = 0.
            instrument.calcPSF(oversample=oversample, fov_pixels=fov_pixels, monochromatic=wave,
                               outfile=longname, clobber='true')

        # Add mode keyword to header
        hdulist = pf.open(longname)
        prihdr = hdulist[0].header
        prihdr['INSTRUME'] = outname
        prihdr['APERTURE'] = (aperture, 'The observing aperture within the instrument FOV')
        prihdr['OFFSET_R'] = (source_offset_r, 'The radial distance in arcsec to the axis')
        prihdr['OFFSET_T'] = (source_offset_theta, 'The source angle in degrees')
        if rot90:
            hdulist[0].data = np.rot90(hdulist[0].data)

        hdulist.writeto(longname, clobber=True)
        hdulist.close()

doWFIRSTImager = True
doWFIRSTIFU = True

if doWFIRSTImager:
    WFIRSTImager = wfirst.WFIRSTImager()
    WFIRSTImager.pixelscale = 0.11
    psf_suite(nw=30, wmin=0.4, wmax=2.6, instrument=WFIRSTImager,
              outname='wfirstimager', fov_pixels=39)

if doWFIRSTIFU:
    WFIRSTImager = wfirst.WFIRSTImager()
    WFIRSTImager.pixelscale = 0.08
    psf_suite(nw=30, wmin=0.4, wmax=2.6, instrument=WFIRSTImager,
              outname='wfirstifu', fov_pixels=39,aperture='ifu')
