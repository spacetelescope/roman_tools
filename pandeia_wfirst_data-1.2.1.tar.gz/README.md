This repository contains the reference data required to configure and perform an ETC calculation.

Make sure you check any new field values against their database maximums.
TODO centralize these constants in #1642

**DO NOT FILE ISSUES IN THIS REPOSITORY**.

For developer sanity, all issues should be filed against the [pandeia](https://github.com/STScI-SSB/pandeia) repo.
